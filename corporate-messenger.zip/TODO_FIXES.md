# 🔧 Список исправлений

## Критические проблемы

### 1. ❌ Редирект после удаления чата
**Проблема:** После удаления чата свайпом перекидывает в пустой чат

**Решение:**
- Проверять текущий роут при удалении
- Если находимся в удаляемом чате - редиректить на /chats
- Код:
```javascript
async function confirmDeleteChat(chat) {
  if (!confirm(`Удалить чат "${chat.displayName || chat.name}"?`)) {
    return
  }
  
  try {
    await api.delete(`/chats/${chat.id}/`)
    chats.value = chats.value.filter(c => c.id !== chat.id)
    delete unreadMessages.value[chat.id]
    delete swipeStates.value[chat.id]
    
    // Если мы в этом чате - редиректим
    if (router.currentRoute.value.params.id == chat.id) {
      router.push('/chats')
    }
  } catch (error) {
    console.error('Delete chat error:', error)
    alert('Ошибка удаления чата')
  }
}
```

### 2. ❌ Статус онлайн не работает автоматически
**Проблема:** Статус не определяется автоматически

**Причина:** Backend не отслеживает подключения WebSocket

**Решение:**
- Backend должен отслеживать активные WebSocket подключения
- При подключении - статус "online"
- При отключении - статус "offline"
- Добавить heartbeat (ping каждые 30 сек)

**Код backend:**
```python
# В websocket_endpoint
await manager.connect(websocket, user_id)

# Обновляем статус в БД
async with async_session_maker() as db:
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user:
        user.status = UserStatus.online
        user.last_seen = datetime.utcnow()
        await db.commit()

# При отключении
user.status = UserStatus.offline
user.last_seen = datetime.utcnow()
await db.commit()
```

### 3. ❌ Трехколоночный layout для веб-версии
**Проблема:** Нет списка чатов слева при открытом чате

**Решение:**
- Создать новый layout для десктопа
- 3 колонки: Sidebar | Список чатов | Открытый чат
- На мобильном - как сейчас (одна колонка)

**Структура:**
```
Desktop (>1024px):
┌─────────┬──────────┬────────────┐
│ Sidebar │  Chats   │ Chat Detail│
│  Menu   │  List    │  Messages  │
└─────────┴──────────┴────────────┘

Mobile (<1024px):
┌────────────┐
│   Chats    │  или  │ Chat Detail│
│   List     │       │  Messages  │
└────────────┘
```

## Дополнительные улучшения

### 4. Проверка дизайна
- Проверить все страницы на битые ссылки
- Проверить темную тему
- Проверить адаптивность
- Исправить отступы и выравнивание

### 5. Оптимизация
- Убрать лишние console.log
- Оптимизировать запросы к API
- Добавить loading состояния

## Приоритеты

1. **Высокий:** Редирект после удаления (критично)
2. **Высокий:** Статус онлайн (важная функция)
3. **Средний:** Трехколоночный layout (улучшение UX)
4. **Низкий:** Проверка дизайна (полировка)

## Оценка времени

- Редирект: 5 минут
- Статус онлайн: 15 минут
- Трехколоночный layout: 30 минут
- Проверка дизайна: 20 минут

**Итого:** ~70 минут

## Что делать сейчас?

Начнем с критических проблем:
1. Исправим редирект после удаления
2. Исправим статус онлайн
3. Добавим трехколоночный layout

Готов начать?
