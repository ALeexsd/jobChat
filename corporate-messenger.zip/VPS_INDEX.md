# 📚 Документация по установке на VPS - Навигация

Полный индекс документации для развертывания корпоративного мессенджера на VPS Ubuntu.

## 🚀 Быстрый старт

**Хотите установить за 5 минут?**

👉 [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md) - Быстрая установка

```bash
ssh root@ваш-сервер-ip
cd /tmp && git clone <repo> corporate-messenger && cd corporate-messenger
chmod +x deploy-ubuntu.sh && sudo bash deploy-ubuntu.sh
```

## 📖 Основная документация

### Для новичков

1. **[README_VPS.md](README_VPS.md)** - Главное руководство
   - Полное руководство по установке
   - Управление приложением
   - Мониторинг и обслуживание
   - Решение проблем
   - **Начните отсюда, если не знаете с чего начать**

2. **[QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md)** - Быстрый старт
   - Установка за 5 минут
   - Минимум текста, максимум действий
   - Основные команды
   - Быстрое решение проблем

3. **[VPS_CHECKLIST.md](VPS_CHECKLIST.md)** - Чеклист установки
   - Пошаговый чеклист
   - Проверка каждого этапа
   - Финальная проверка
   - Список частых проблем

### Для опытных пользователей

4. **[INSTALL_VPS.md](INSTALL_VPS.md)** - Подробная инструкция
   - Ручная пошаговая установка
   - Детальная настройка каждого компонента
   - Все конфигурационные файлы
   - Продвинутые настройки

5. **[VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md)** - Требования
   - Системные требования
   - Выбор провайдера VPS
   - Расчет стоимости
   - Рекомендации по конфигурации
   - Масштабирование

6. **[DEPLOYMENT.md](DEPLOYMENT.md)** - Production развертывание
   - Production конфигурация
   - Оптимизация производительности
   - Безопасность
   - Мониторинг

## 🔧 Справочники

7. **[COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md)** - Справочник команд
   - Все команды для управления
   - Docker команды
   - Nginx команды
   - Системные команды
   - Быстрая справка

8. **[VPS_SETUP_SUMMARY.md](VPS_SETUP_SUMMARY.md)** - Резюме
   - Краткое описание всех файлов
   - Что было создано
   - Как использовать
   - Быстрая навигация

## 🛠️ Скрипты

### Автоматизация

9. **deploy-ubuntu.sh** - Автоматическая установка
   ```bash
   sudo bash deploy-ubuntu.sh
   ```
   - Полная автоматическая установка
   - Настройка всех компонентов
   - Получение SSL сертификата
   - Создание администратора

10. **update-app.sh** - Обновление приложения
    ```bash
    sudo bash update-app.sh
    ```
    - Автоматическое обновление
    - Создание бэкапа перед обновлением
    - Применение миграций

11. **restore-backup.sh** - Восстановление из бэкапа
    ```bash
    sudo bash restore-backup.sh backup_file.sql.gz
    ```
    - Восстановление БД из бэкапа
    - Создание страховочного бэкапа
    - Безопасное восстановление

### Мониторинг и обслуживание

12. **check-health.sh** - Проверка здоровья
    ```bash
    bash check-health.sh
    # или
    chat-health
    ```
    - Проверка всех компонентов
    - Мониторинг ресурсов
    - Анализ логов
    - Рекомендации

13. **monitoring-setup.sh** - Настройка мониторинга
    ```bash
    sudo bash monitoring-setup.sh your@email.com
    ```
    - Автоматический мониторинг
    - Email уведомления
    - Ежедневные отчеты
    - Алерты при проблемах

## 📋 Использование по сценариям

### Сценарий 1: Первая установка

**Вы никогда не устанавливали приложение на VPS**

1. Прочитайте [VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md) - выберите VPS
2. Следуйте [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md) - установите
3. Используйте [VPS_CHECKLIST.md](VPS_CHECKLIST.md) - проверьте
4. Сохраните [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md) - для справки

**Время: 30-40 минут**

### Сценарий 2: Детальная установка

**Вы хотите понимать каждый шаг**

1. Прочитайте [README_VPS.md](README_VPS.md) - общее понимание
2. Изучите [VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md) - требования
3. Следуйте [INSTALL_VPS.md](INSTALL_VPS.md) - ручная установка
4. Настройте по [DEPLOYMENT.md](DEPLOYMENT.md) - production конфигурация

**Время: 1-2 часа**

### Сценарий 3: Быстрая установка

**Вы опытный пользователь, нужно быстро**

1. Запустите `deploy-ubuntu.sh`
2. Проверьте по [VPS_CHECKLIST.md](VPS_CHECKLIST.md)
3. Готово!

**Время: 10-15 минут**

### Сценарий 4: Обслуживание

**Приложение уже установлено, нужно обслуживать**

1. Используйте [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md) - команды
2. Запускайте `check-health.sh` - проверка
3. Используйте `update-app.sh` - обновления
4. Используйте `chat-backup` - бэкапы

**Время: 5-10 минут в день**

### Сценарий 5: Решение проблем

**Что-то не работает**

1. Запустите `chat-health` - диагностика
2. Проверьте логи: `chat-logs`
3. Смотрите раздел "Решение проблем" в [README_VPS.md](README_VPS.md)
4. Используйте [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md) для команд

## 🎯 Рекомендуемый порядок чтения

### Для начинающих

```
1. README_VPS.md (обзор)
   ↓
2. VPS_REQUIREMENTS.md (выбор VPS)
   ↓
3. QUICK_INSTALL_VPS.md (установка)
   ↓
4. VPS_CHECKLIST.md (проверка)
   ↓
5. COMMANDS_REFERENCE.md (сохранить для справки)
```

### Для опытных

```
1. VPS_REQUIREMENTS.md (требования)
   ↓
2. INSTALL_VPS.md (детальная установка)
   ↓
3. DEPLOYMENT.md (production настройка)
   ↓
4. COMMANDS_REFERENCE.md (справка)
```

### Для администраторов

```
1. README_VPS.md (обзор)
   ↓
2. DEPLOYMENT.md (production)
   ↓
3. monitoring-setup.sh (мониторинг)
   ↓
4. COMMANDS_REFERENCE.md (ежедневное использование)
```

## 📊 Сравнение документов

| Документ | Уровень | Время чтения | Когда использовать |
|----------|---------|--------------|-------------------|
| QUICK_INSTALL_VPS.md | Начальный | 5 мин | Быстрая установка |
| README_VPS.md | Средний | 15 мин | Полное понимание |
| INSTALL_VPS.md | Продвинутый | 30 мин | Ручная установка |
| VPS_REQUIREMENTS.md | Начальный | 10 мин | Выбор VPS |
| DEPLOYMENT.md | Продвинутый | 20 мин | Production |
| COMMANDS_REFERENCE.md | Любой | 5 мин | Справка |
| VPS_CHECKLIST.md | Начальный | 10 мин | Проверка |

## 🔍 Поиск информации

### Хочу узнать про...

**Установку:**
- Быстро → [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md)
- Подробно → [INSTALL_VPS.md](INSTALL_VPS.md)
- Автоматически → `deploy-ubuntu.sh`

**Требования:**
- Системные → [VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md)
- Провайдеры → [VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md)
- Стоимость → [VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md)

**Управление:**
- Команды → [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md)
- Обновление → `update-app.sh`
- Бэкапы → [README_VPS.md](README_VPS.md) + `restore-backup.sh`

**Мониторинг:**
- Настройка → `monitoring-setup.sh`
- Проверка → `check-health.sh`
- Dashboard → `chat-dashboard`

**Проблемы:**
- Диагностика → `chat-health`
- Решения → [README_VPS.md](README_VPS.md) раздел "Решение проблем"
- Команды → [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md)

**Безопасность:**
- Настройка → [README_VPS.md](README_VPS.md) раздел "Безопасность"
- Production → [DEPLOYMENT.md](DEPLOYMENT.md)
- SSL → [INSTALL_VPS.md](INSTALL_VPS.md)

## 💡 Полезные советы

### Сохраните закладки

Добавьте в закладки браузера:
- [README_VPS.md](README_VPS.md) - главное руководство
- [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md) - команды
- [VPS_CHECKLIST.md](VPS_CHECKLIST.md) - чеклист

### Распечатайте

Для быстрого доступа распечатайте:
- [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md)
- [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md)
- [VPS_CHECKLIST.md](VPS_CHECKLIST.md)

### Создайте шпаргалку

Скопируйте часто используемые команды из [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md) в отдельный файл.

## 📞 Поддержка

### Порядок действий при проблемах

1. **Проверьте документацию**
   - Поищите в этом индексе
   - Проверьте раздел "Решение проблем"

2. **Запустите диагностику**
   ```bash
   chat-health
   chat-status
   chat-logs
   ```

3. **Проверьте логи**
   - Backend: `docker-compose logs backend`
   - Frontend: `docker-compose logs frontend`
   - Nginx: `sudo tail -f /var/log/nginx/error.log`

4. **Создайте issue**
   - Опишите проблему
   - Приложите логи
   - Укажите конфигурацию

## ✅ Быстрая проверка

После установки выполните:

```bash
# 1. Проверка здоровья
chat-health

# 2. Статус контейнеров
chat-status

# 3. Открыть в браузере
# https://ваш-домен.com

# 4. Войти
# admin / admin123

# 5. Сменить пароль!
```

## 🎉 Готово!

Теперь у вас есть полная документация для работы с приложением на VPS.

**Следующий шаг:** Выберите сценарий выше и начните установку!

---

**Вопросы?** Начните с [README_VPS.md](README_VPS.md) или создайте issue в GitHub.

**Быстрый старт?** Запустите [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md)

**Нужна помощь?** Проверьте [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md)
