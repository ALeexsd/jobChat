# 🧪 Инструкция по тестированию WebSocket

## Проблема
WebSocket не подключается, показывает ошибку 1006.

## 🔍 Диагностика

### Вариант 1: Тест через HTML страницу (РЕКОМЕНДУЕТСЯ)

1. Откройте файл `test_websocket.html` в браузере
2. Откройте http://localhost:3000 в другой вкладке
3. Войдите как admin / admin123
4. Откройте консоль (F12) и выполните:
   ```javascript
   localStorage.getItem('access_token')
   ```
5. Скопируйте токен
6. Вернитесь на вкладку с `test_websocket.html`
7. Вставьте токен в поле
8. Нажмите "Подключиться к WebSocket"

**Ожидаемый результат:**
```
✅ WebSocket подключен!
📨 Получено сообщение: {"type":"connected",...}
```

**Если ошибка:**
- Скопируйте все логи из тестовой страницы
- Выполните: `docker logs chat_backend --tail 100`
- Отправьте мне оба лога

### Вариант 2: Тест через консоль браузера

1. Откройте http://localhost:3000
2. Войдите как admin / admin123
3. Откройте консоль (F12)
4. Выполните:

```javascript
// Получаем токен
const token = localStorage.getItem('access_token')
console.log('Token:', token)

// Подключаемся к WebSocket
const ws = new WebSocket(`ws://localhost:8000/ws?token=${token}`)

ws.onopen = () => {
    console.log('✅ WebSocket OPENED!')
    console.log('ReadyState:', ws.readyState)
}

ws.onmessage = (e) => {
    console.log('📨 Message:', e.data)
}

ws.onerror = (e) => {
    console.error('❌ Error:', e)
}

ws.onclose = (e) => {
    console.log('🔌 Closed:', e.code, e.reason)
}
```

**Ожидаемый результат:**
```
✅ WebSocket OPENED!
ReadyState: 1
📨 Message: {"type":"connected",...}
```

## 🐛 Возможные проблемы

### Проблема 1: Код 1006 (Abnormal Closure)

**Причина:** Backend не принимает подключение

**Проверка:**
```bash
docker logs chat_backend -f
```

При попытке подключения должны быть логи:
```
INFO: WebSocket connection attempt with token: eyJhbGciOiJIUzI1NiIs...
```

**Если логов нет:**
- Backend не получает запрос
- Проверьте, что backend запущен: `docker ps | grep chat_backend`
- Перезапустите: `docker restart chat_backend`

### Проблема 2: Код 1008 (Policy Violation)

**Причина:** Токен невалидный или отсутствует

**Решение:**
1. Выйдите из приложения
2. Войдите снова
3. Получите новый токен
4. Попробуйте снова

### Проблема 3: Нет логов в backend

**Причина:** Запрос не доходит до backend

**Проверка:**
```bash
# Проверьте, что backend слушает на порту 8000
curl http://localhost:8000/
# Должен вернуть: {"message":"Corporate Messenger API","version":"1.0.0"}
```

**Если не отвечает:**
```bash
docker restart chat_backend
```

## 📊 Backend логи

При успешном подключении должны быть:
```
INFO: WebSocket connection attempt with token: eyJhbGciOiJIUzI1NiIs...
INFO: User 1 connected. Total connections: 1
INFO: Added user 1 to chat 9
INFO: Added user 1 to chat 10
INFO: Added user 1 to chat 19
```

## 🔧 Быстрые команды

### Перезапуск всего
```bash
docker-compose restart
```

### Просмотр логов backend в реальном времени
```bash
docker logs chat_backend -f
```

### Проверка статуса
```bash
docker-compose ps
```

### Проверка API
```bash
curl http://localhost:8000/
```

## ✅ Если WebSocket подключился

Отлично! Теперь протестируйте отправку сообщений:

1. Откройте два окна браузера
2. Войдите как user1 в первом, user2 во втором
3. Отправьте сообщение из первого окна
4. Проверьте, что во втором окне:
   - Появилось сообщение
   - Чат переместился наверх
   - Появился счетчик

## ❌ Если WebSocket не подключается

Выполните полную диагностику:

1. **Проверьте backend:**
   ```bash
   docker logs chat_backend --tail 100 > backend_logs.txt
   ```

2. **Проверьте frontend:**
   - Откройте консоль (F12)
   - Скопируйте все логи

3. **Проверьте подключение вручную:**
   - Используйте `test_websocket.html`
   - Скопируйте логи

4. **Отправьте мне:**
   - backend_logs.txt
   - Логи из консоли браузера
   - Логи из test_websocket.html

---

## 🎯 Следующий шаг

**Откройте `test_websocket.html` в браузере и выполните тест!**

Файл находится в корне проекта: `E:\ch2\test_websocket.html`

Просто откройте его двойным кликом или перетащите в браузер.

---

**Дата:** 23.11.2025 12:35
