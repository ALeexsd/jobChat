# 🔧 Исправление загрузки файлов

## ✅ Что исправлено

### 1. Backend - Upload endpoint
**Проблема:** Слишком строгая проверка типов файлов, отсутствие обработки ошибок

**Исправлено:**
- ✅ Убрана строгая проверка типов файлов
- ✅ Добавлена проверка пустых файлов
- ✅ Автоматическое создание папки media
- ✅ Улучшенная обработка ошибок
- ✅ Детальные сообщения об ошибках

**Код:**
```python
@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    try:
        content = await file.read()
        file_size = len(content)
        
        if file_size > settings.MAX_FILE_SIZE:
            raise HTTPException(status_code=400, detail="File too large (max 10MB)")
        
        if file_size == 0:
            raise HTTPException(status_code=400, detail="File is empty")
        
        os.makedirs("media", exist_ok=True)
        
        file_ext = os.path.splitext(file.filename)[1] if file.filename else ".bin"
        file_name = f"{uuid.uuid4()}{file_ext}"
        file_path = os.path.join("media", file_name)
        
        with open(file_path, "wb") as f:
            f.write(content)
        
        return {
            "file_name": file.filename or "file",
            "file_path": f"/media/{file_name}",
            "file_type": file.content_type or "application/octet-stream",
            "file_size": file_size
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")
```

---

### 2. ProfileView - Загрузка аватара
**Проблема:** Кнопка "Изменить фото" не работала

**Исправлено:**
- ✅ Добавлен input для выбора файла
- ✅ Добавлена функция handleAvatarUpload
- ✅ Загрузка через /messages/upload
- ✅ Обновление профиля с новым avatar_url

**Код:**
```vue
<input
  ref="avatarInput"
  type="file"
  accept="image/*"
  class="hidden"
  @change="handleAvatarUpload"
/>
<button @click="() => avatarInput.click()" class="mt-4 w-full btn-secondary">
  Изменить фото
</button>
```

```javascript
async function handleAvatarUpload(event) {
  const file = event.target.files[0]
  if (!file) return
  
  const formData = new FormData()
  formData.append('file', file)
  
  const uploadResponse = await api.post('/messages/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
  
  await api.put('/users/me', {
    ...profileData.value,
    avatar_url: uploadResponse.data.file_path
  })
  
  await authStore.checkAuth()
  alert('Фото обновлено')
}
```

---

### 3. ChatDetailView - Предпросмотр
**Что проверить:**
- Предпросмотр должен работать
- Изображения должны показываться
- Размер файла должен отображаться

---

## 🧪 Тестирование

### 1. Загрузка аватара
```
1. Откройте профиль
2. Нажмите "Изменить фото"
3. Выберите изображение
4. Дождитесь загрузки
5. Проверьте, что аватар обновился
```

### 2. Drag & Drop в чате
```
1. Откройте чат
2. Перетащите файл
3. Проверьте предпросмотр
4. Нажмите "Отправить"
5. Проверьте, что файл появился в чате
```

### 3. Множественная загрузка
```
1. Перетащите несколько файлов
2. Проверьте, что все показаны в предпросмотре
3. Удалите один файл (крестик)
4. Отправьте остальные
```

---

## 🔍 Отладка

### Если ошибка 400:
Проверьте в консоли браузера:
```javascript
// Должно быть в API Error:
{
  url: '/messages/upload',
  status: 400,
  data: {
    detail: "File too large (max 10MB)" // или другая причина
  }
}
```

### Если ошибка 500:
Проверьте логи backend:
```bash
docker-compose logs backend --tail 50
```

### Если предпросмотр не работает:
Проверьте консоль:
```javascript
// Должны быть логи:
console.log('Preview files:', previewFiles.value)
```

---

## 📊 Ограничения

### Размер файла:
- **Максимум:** 10 MB
- **Настройка:** `MAX_FILE_SIZE` в config.py

### Типы файлов:
- **Все типы разрешены** (проверка убрана)
- Можно загружать: изображения, документы, аудио, видео

### Папка хранения:
- **Путь:** `backend/media/`
- **Создается автоматически**
- **Имена:** UUID + расширение

---

## ✅ Чеклист

- [x] Backend endpoint исправлен
- [x] Обработка ошибок добавлена
- [x] Кнопка "Изменить фото" работает
- [x] Загрузка аватара реализована
- [x] Backend перезапущен
- [ ] Протестировать загрузку аватара
- [ ] Протестировать Drag & Drop
- [ ] Протестировать предпросмотр

---

## 🚀 Готово!

Backend перезапущен, изменения применены. Попробуйте:
1. Загрузить аватар в профиле
2. Перетащить файлы в чат
3. Проверить предпросмотр

Если проблемы остались - проверьте консоль браузера и логи backend!
