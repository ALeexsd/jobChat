# ✅ Сотрудники и улучшения

## 🎯 Что добавлено

1. **Переход на профиль из чата**
2. **Раздел "Сотрудники"**
3. **Скрытие нижнего бара в чатах**

---

## 👥 Раздел "Сотрудники"

### Новый раздел для просмотра всех пользователей

**Функции:**
- ✅ Список всех сотрудников
- ✅ Аватар, имя, фамилия, должность
- ✅ Статус (онлайн/оффлайн)
- ✅ Поиск по имени, фамилии, username, должности
- ✅ Кнопка "Написать сообщение"
- ✅ Клик на карточку → профиль пользователя

### Интерфейс

**Карточка сотрудника:**
```
┌─────────────────────────────────┐
│  [👤]  Иван Иванов              │
│        @ivan                     │
│        Разработчик               │
│        🟢 Онлайн                 │
│                                  │
│  [💬 Написать сообщение]         │
└─────────────────────────────────┘
```

**Адаптивная сетка:**
- Мобильный: 1 колонка
- Планшет: 2 колонки
- Десктоп: 3 колонки

### Код

**frontend/src/views/EmployeesView.vue:**
```vue
<template>
  <div class="h-full flex flex-col p-6">
    <h1 class="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-6">Сотрудники</h1>
    
    <!-- Search -->
    <div class="mb-6">
      <div class="relative">
        <MagnifyingGlassIcon class="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          v-model="searchQuery"
          type="text"
          placeholder="Поиск сотрудников..."
          class="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:text-gray-100"
        />
      </div>
    </div>
    
    <!-- Employees Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <div
        v-for="employee in filteredEmployees"
        :key="employee.id"
        @click="goToProfile(employee.id)"
        class="card p-4 hover:shadow-lg transition-shadow cursor-pointer"
      >
        <!-- Avatar + Info -->
        <div class="flex items-start">
          <div class="w-16 h-16 rounded-full bg-primary-600 flex items-center justify-center text-white text-xl font-semibold">
            {{ getInitials(employee) }}
          </div>
          
          <div class="ml-4 flex-1">
            <h3 class="text-lg font-semibold text-gray-900">
              {{ employee.first_name }} {{ employee.last_name }}
            </h3>
            <p class="text-sm text-gray-600">@{{ employee.username }}</p>
            <p class="text-sm text-gray-500">{{ employee.position }}</p>
            
            <!-- Status -->
            <div class="flex items-center mt-2">
              <div class="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
              <span class="text-xs text-gray-500">Онлайн</span>
            </div>
          </div>
        </div>
        
        <!-- Action Button -->
        <button
          @click.stop="createChat(employee)"
          class="mt-4 w-full btn-primary flex items-center justify-center"
        >
          <ChatBubbleLeftRightIcon class="w-5 h-5 mr-2" />
          Написать сообщение
        </button>
      </div>
    </div>
  </div>
</template>
```

**Функции:**
```javascript
// Переход на профиль
function goToProfile(userId) {
  router.push(`/users/${userId}`)
}

// Создание чата
async function createChat(employee) {
  try {
    const response = await api.post('/chats', {
      name: `${employee.first_name} ${employee.last_name}`,
      chat_type: 'private',
      member_ids: [employee.id]
    })
    
    router.push(`/chats/${response.data.id}`)
  } catch (error) {
    console.error('Create chat error:', error)
    alert('Ошибка создания чата')
  }
}
```

---

## 💬 Переход на профиль из чата

### Проблема
Из чата нельзя было перейти на профиль собеседника.

### Решение

**Кликабельный заголовок чата:**
```vue
<button @click="goToUserProfile" class="flex items-center hover:bg-gray-50 rounded-lg p-2 -ml-2 transition-colors">
  <div class="w-10 h-10 rounded-full bg-primary-600 flex items-center justify-center text-white font-semibold">
    {{ chat?.name?.[0] || '?' }}
  </div>
  
  <div class="ml-3 text-left">
    <h2 class="text-lg font-semibold text-gray-900">{{ chat?.name || 'Чат' }}</h2>
    <p v-if="isTyping" class="text-sm text-primary-600">печатает...</p>
  </div>
</button>
```

**Функция перехода:**
```javascript
function goToUserProfile() {
  // Для личных чатов переходим на профиль собеседника
  if (chat.value?.chat_type === 'private' && chat.value?.members?.length > 0) {
    // Находим собеседника (не текущего пользователя)
    const otherMember = chat.value.members.find(m => m.user_id !== currentUserId.value)
    if (otherMember) {
      router.push(`/users/${otherMember.user_id}`)
    }
  }
}
```

### Результат:
- ✅ Клик на заголовок чата → профиль собеседника
- ✅ Работает только для личных чатов
- ✅ Hover эффект для понятности

---

## 📱 Скрытие нижнего бара в чатах

### Проблема
Нижний навбар мешал в открытом чате на мобильных.

### Решение

**Условное отображение:**
```vue
<!-- Mobile Bottom Navigation (скрыт в чатах) -->
<nav v-if="!route.path.startsWith('/chats/')" class="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-50">
  <!-- Навбар -->
</nav>
```

**Адаптивный отступ:**
```vue
<main :class="[
  'flex-1 overflow-auto',
  route.path.startsWith('/chats/') ? 'pb-0' : 'pb-16 lg:pb-0'
]">
  <router-view />
</main>
```

### Логика:
- ✅ `/chats` - навбар показан
- ✅ `/chats/1` - навбар скрыт
- ✅ `/chats/2` - навбар скрыт
- ✅ Другие разделы - навбар показан

### Результат:
- ✅ В списке чатов - навбар виден
- ✅ В открытом чате - навбар скрыт
- ✅ Больше места для сообщений
- ✅ Удобнее печатать

---

## 🧪 Тестирование

### Тест 1: Раздел "Сотрудники"

**Шаги:**
1. Откройте меню
2. Нажмите "Сотрудники"
3. Посмотрите список

**Ожидаемый результат:**
- ✅ Отображается список всех пользователей
- ✅ Видны аватары, имена, должности
- ✅ Есть кнопка "Написать сообщение"

---

### Тест 2: Поиск сотрудников

**Шаги:**
1. В разделе "Сотрудники"
2. Введите в поиске: "Иван"
3. Посмотрите результаты

**Ожидаемый результат:**
- ✅ Фильтруются сотрудники по имени
- ✅ Также ищет по фамилии, username, должности

---

### Тест 3: Создание чата из карточки

**Шаги:**
1. В разделе "Сотрудники"
2. Нажмите "Написать сообщение" на карточке
3. Дождитесь перехода

**Ожидаемый результат:**
- ✅ Создается личный чат
- ✅ Открывается чат
- ✅ Можно сразу писать

---

### Тест 4: Переход на профиль из карточки

**Шаги:**
1. В разделе "Сотрудники"
2. Кликните на карточку (не на кнопку)
3. Дождитесь перехода

**Ожидаемый результат:**
- ✅ Открывается профиль пользователя
- ✅ Видна вся информация
- ✅ Есть кнопка "Написать сообщение"

---

### Тест 5: Переход на профиль из чата

**Шаги:**
1. Откройте личный чат
2. Кликните на заголовок чата (имя собеседника)
3. Дождитесь перехода

**Ожидаемый результат:**
- ✅ Открывается профиль собеседника
- ✅ Можно посмотреть информацию
- ✅ Можно вернуться в чат

---

### Тест 6: Нижний бар в чатах (мобильный)

**Шаги:**
1. Откройте на мобильном (или уменьшите окно)
2. Перейдите в "Чаты"
3. Посмотрите вниз

**Ожидаемый результат:**
- ✅ Нижний бар виден

**Шаги:**
1. Откройте любой чат
2. Посмотрите вниз

**Ожидаемый результат:**
- ✅ Нижний бар скрыт
- ✅ Больше места для сообщений

---

## 📊 Навигация

### Боковое меню (десктоп):
```
💬 Чаты
👥 Сотрудники ← Новое!
✅ Задачи
📝 Заметки
📅 Отпуска
🗺️ Маршруты
```

### Нижний бар (мобильный):
```
Список чатов:
💬 Чаты | ✅ Задачи | 📝 Заметки | 👤 Профиль

Открытый чат:
[Нижний бар скрыт]
```

---

## 🎯 Сценарии использования

### Сценарий 1: Найти коллегу и написать
1. Пользователь открывает "Сотрудники"
2. Ищет коллегу по имени
3. Нажимает "Написать сообщение"
4. Чат создается автоматически
5. Можно сразу писать

### Сценарий 2: Посмотреть профиль коллеги
1. Пользователь открывает "Сотрудники"
2. Кликает на карточку коллеги
3. Открывается профиль
4. Видит всю информацию
5. Может написать сообщение

### Сценарий 3: Из чата в профиль
1. Пользователь в личном чате
2. Кликает на имя собеседника
3. Открывается профиль
4. Изучает информацию
5. Возвращается в чат

### Сценарий 4: Удобный чат на мобильном
1. Пользователь открывает чат
2. Нижний бар скрывается
3. Больше места для сообщений
4. Удобнее печатать
5. Выходит из чата - бар появляется

---

## 🚀 Frontend обновлен

Все функции добавлены!

**Попробуйте сейчас:**
1. Откройте "Сотрудники" в меню
2. Найдите коллегу
3. Напишите сообщение или откройте профиль
4. В чате кликните на имя → профиль
5. На мобильном откройте чат → бар скроется

Все работает! 👥✨
