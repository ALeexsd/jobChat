# 🧪 Тестирование логина

## ✅ Backend работает!

Проверено через PowerShell:
- ✅ Регистрация работает
- ✅ Логин работает
- ✅ Токены возвращаются

## 👤 Тестовый пользователь создан

```
Username: testuser
Password: test123
```

## 🔍 Как протестировать

### 1. Откройте приложение
```
http://localhost:3000
```

### 2. Откройте консоль браузера (F12)

### 3. Попробуйте войти
- Username: `testuser`
- Password: `test123`

### 4. Проверьте консоль
Должны увидеть логи:
```
Attempting login with: {username: "testuser", password: "test123"}
Login credentials: {username: "testuser", password: "test123"}
Login response: {access_token: "...", refresh_token: "...", token_type: "bearer"}
```

## 🐛 Если ошибка 422

Проверьте в консоли браузера:
1. Что именно отправляется в запросе
2. Формат данных (должен быть JSON)
3. Headers (должен быть Content-Type: application/json)

### Возможные причины:

1. **Пустые поля**
   - Убедитесь, что заполнили username и password

2. **Неправильный формат**
   - Данные должны быть: `{username: "...", password: "..."}`

3. **Проблема с CORS**
   - Проверьте Network tab в DevTools

## 🔧 Создание нового пользователя

### Через регистрацию:
1. Нажмите "Зарегистрироваться"
2. Заполните форму:
   - Имя: Иван
   - Фамилия: Иванов
   - Username: ivan
   - Email: ivan@test.com
   - Пароль: 123456

3. Нажмите "Зарегистрироваться"
4. Войдите с новыми данными

### Через PowerShell:
```powershell
Invoke-WebRequest -Uri "http://localhost:8000/api/auth/register" -Method POST -Headers @{"Content-Type"="application/json"} -Body '{"username":"user2","password":"pass123","first_name":"User","last_name":"Two"}'
```

## ✅ Проверка работы

После успешного входа:
1. Должны увидеть главную страницу
2. Sidebar слева
3. Список чатов (пустой)
4. Профиль пользователя внизу sidebar

## 📝 Логи для отладки

Добавлены console.log в:
- `LoginView.vue` - перед отправкой
- `auth.js` - в store перед и после запроса

Проверьте консоль браузера для деталей!
