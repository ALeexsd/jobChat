# 💬 Корпоративный мессенджер с управлением задачами

Полнофункциональный self-hosted корпоративный мессенджер с чатами, задачами, маршрутами, отпусками и днями рождения.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Python](https://img.shields.io/badge/python-3.11+-blue.svg)
![Vue](https://img.shields.io/badge/vue-3.3+-green.svg)
![FastAPI](https://img.shields.io/badge/fastapi-0.104+-teal.svg)

## 🌟 Особенности

- 💬 **Реалтайм чаты** - личные и групповые с WebSocket
- 📄 **Просмотр документов** - PDF и Word прямо в чатах с редактированием и печатью
- 😊 **Эмодзи пикер** - 1800+ эмодзи с поиском и категориями
- 📝 **Управление задачами** - с подзадачами, комментариями и тегами
- 🚗 **Маршруты** - планирование и отслеживание маршрутов сотрудников
- 🗒 **Заметки** - личные заметки и заметки о коллегах
- 🏖 **Отпуска** - календарь и управление отпусками
- 🎂 **Дни рождения** - автоматические напоминания
- 🔔 **Уведомления** - централизованная система уведомлений
- 🎨 **Темная тема** - светлая и темная темы интерфейса
- 📱 **Адаптивный дизайн** - работает на всех устройствах
- 🔐 **Безопасность** - JWT аутентификация, роли и права доступа

## 🚀 Технологии

### Backend
- **FastAPI** - современный async веб-фреймворк
- **SQLAlchemy 2.0** - ORM с async поддержкой
- **PostgreSQL** - надежная реляционная БД
- **WebSockets** - реалтайм коммуникация
- **JWT** - безопасная аутентификация
- **Alembic** - миграции базы данных

### Frontend
- **Vue.js 3** - прогрессивный JavaScript фреймворк
- **Composition API** - современный подход к компонентам
- **Pinia** - state management
- **Vue Router** - маршрутизация
- **Axios** - HTTP клиент
- **SCSS** - мощные стили

### Infrastructure
- **Docker** - контейнеризация
- **Docker Compose** - оркестрация сервисов

## 📦 Быстрый старт

### 🚀 Установка на VPS Ubuntu (Production)

**Готовы к production развертыванию?**

👉 **[START_HERE.md](START_HERE.md)** - Начните здесь для установки на VPS

**Автоматическая установка за 10 минут:**
```bash
ssh root@ваш-сервер-ip
cd /tmp && git clone <repository-url> corporate-messenger && cd corporate-messenger
chmod +x deploy-ubuntu.sh && sudo bash deploy-ubuntu.sh
```

**Документация по VPS:**
- [START_HERE.md](START_HERE.md) - Быстрый старт
- [README_VPS.md](README_VPS.md) - Полное руководство
- [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md) - Установка за 5 минут
- [VPS_INDEX.md](VPS_INDEX.md) - Навигация по документации

---

### 💻 Локальная разработка

### Требования
- Docker и Docker Compose
- (Опционально) Node.js 18+ и Python 3.11+ для локальной разработки

### Установка

1. **Клонируйте репозиторий**
```bash
git clone <repository-url>
cd corporate-messenger
```

2. **Настройте переменные окружения**
```bash
# Backend
cp backend/.env.example backend/.env

# Frontend
cp frontend/.env.example frontend/.env
```

3. **Запустите через Docker Compose**
```bash
docker-compose up -d
```

4. **Примените миграции БД**
```bash
docker-compose exec backend alembic upgrade head
```

5. **Создайте администратора**
```bash
docker-compose exec backend python scripts/create_admin.py
```

Учетные данные по умолчанию:
- **Username**: `admin`
- **Password**: `admin123`

### Доступ к приложению

- 🌐 **Frontend**: http://localhost:3000
- 🔧 **Backend API**: http://localhost:8000
- 📚 **API Docs**: http://localhost:8000/docs
- 📖 **ReDoc**: http://localhost:8000/redoc

## 📖 Документация

### Основная
- [📋 Полная документация по установке](SETUP.md)
- [🏗 Архитектура проекта](ARCHITECTURE.md)
- [🔌 API документация](API_DOCUMENTATION.md)
- [✨ Список функций](FEATURES.md)

### Новые функции (v2.0)
- [🎉 Финальная сводка обновлений](FINAL_UPDATE_SUMMARY.md)
- [🚀 Быстрый старт с новыми функциями](NEW_FEATURES_QUICKSTART.md)
- [📄 Просмотр документов](DOCUMENT_VIEWER_COMPLETE.md)
- [✅ Чеклист тестирования](TESTING_CHECKLIST.md)

## 🎯 Основные функции

### 💬 Чаты и сообщения
- Личные и групповые чаты
- Текст, изображения, файлы, голосовые сообщения
- **📄 Просмотр PDF и Word документов** - встроенный просмотрщик
- Реакции и эмодзи
- Редактирование и удаление сообщений
- Пересылка и ответы
- Статусы доставки и прочтения
- Индикатор "печатает..."

### 📝 Задачи
- Создание задач с приоритетами
- Назначение исполнителей
- Подзадачи
- Комментарии
- Теги и категории
- Дедлайны и напоминания

### 🚗 Маршруты
- Планирование маршрутов
- Множественные локации
- Назначение сотрудников
- Отслеживание статусов
- Реалтайм обновления

### 🗒 Заметки
- Личные заметки
- Заметки о коллегах (приватные)
- Категории и теги
- Закрепленные заметки

### 🏖 Отпуска
- Запросы на отпуск
- Утверждение/отклонение
- Календарь отпусков
- Уведомления

### 🎂 Дни рождения
- Автоматический список
- Уведомления в день рождения
- Быстрый доступ к поздравлениям

## 🔐 Роли и права доступа

| Роль | Описание | Права |
|------|----------|-------|
| **Admin** | Администратор | Полный доступ ко всем функциям |
| **Manager** | Менеджер | Управление задачами, маршрутами, утверждение отпусков |
| **Employee** | Сотрудник | Базовый доступ к чатам, задачам, заметкам |

## 🛠 Разработка

### Backend (локально)
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
alembic upgrade head
uvicorn app.main:app --reload
```

### Frontend (локально)
```bash
cd frontend
npm install
npm run dev
```

### Создание миграций
```bash
docker-compose exec backend alembic revision --autogenerate -m "description"
docker-compose exec backend alembic upgrade head
```

### Тесты
```bash
cd backend
pytest
```

## 📁 Структура проекта

```
corporate-messenger/
├── backend/
│   ├── app/
│   │   ├── api/              # REST API endpoints
│   │   ├── core/             # Конфигурация и безопасность
│   │   ├── models/           # SQLAlchemy модели
│   │   ├── schemas/          # Pydantic схемы
│   │   ├── websocket/        # WebSocket handlers
│   │   └── main.py           # Точка входа
│   ├── alembic/              # Миграции БД
│   ├── scripts/              # Утилиты
│   └── tests/                # Тесты
├── frontend/
│   ├── src/
│   │   ├── assets/           # Стили и изображения
│   │   ├── components/       # Vue компоненты
│   │   ├── router/           # Маршрутизация
│   │   ├── services/         # API и WebSocket
│   │   ├── stores/           # Pinia stores
│   │   ├── views/            # Страницы
│   │   └── main.js           # Точка входа
│   └── public/               # Статические файлы
├── docker-compose.yml        # Docker Compose конфигурация
├── README.md                 # Этот файл
├── SETUP.md                  # Инструкция по установке
├── ARCHITECTURE.md           # Архитектура проекта
├── API_DOCUMENTATION.md      # API документация
└── FEATURES.md               # Список функций
```

## 🤝 Вклад в проект

Мы приветствуем вклад в проект! Пожалуйста:

1. Fork репозиторий
2. Создайте feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit изменения (`git commit -m 'Add some AmazingFeature'`)
4. Push в branch (`git push origin feature/AmazingFeature`)
5. Откройте Pull Request

## 📝 Лицензия

Этот проект распространяется под лицензией MIT. См. файл `LICENSE` для подробностей.

## 🙏 Благодарности

- [FastAPI](https://fastapi.tiangolo.com/) - за отличный веб-фреймворк
- [Vue.js](https://vuejs.org/) - за реактивный UI фреймворк
- [SQLAlchemy](https://www.sqlalchemy.org/) - за мощную ORM
- [PostgreSQL](https://www.postgresql.org/) - за надежную БД

## 📧 Контакты

Если у вас есть вопросы или предложения, создайте Issue в репозитории.

---

Сделано с ❤️ для корпоративной коммуникации
