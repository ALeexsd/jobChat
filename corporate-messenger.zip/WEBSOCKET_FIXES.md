# ✅ Исправления WebSocket и UI

## 🔧 Что было исправлено

### 1. ✅ WebSocket подключение
**Проблема:** WebSocket не работал корректно

**Решение:**
- Добавлено автоматическое добавление пользователя во все его чаты при подключении
- Улучшено логирование для отладки
- Добавлен fallback механизм отправки уведомлений всем подключенным пользователям
- Добавлено ожидание подключения перед подпиской на события

**Код:**
```javascript
// Frontend - ожидание подключения
if (!websocket.isConnected()) {
  websocket.connect()
  await new Promise((resolve) => {
    if (websocket.isConnected()) {
      resolve()
    } else {
      const unsubscribe = websocket.on('connected', () => {
        unsubscribe()
        resolve()
      })
      setTimeout(resolve, 3000)
    }
  })
}
```

```python
# Backend - автоматическое добавление в чаты
async with async_session_maker() as db:
    result = await db.execute(
        select(ChatMember.chat_id).where(ChatMember.user_id == user_id)
    )
    chat_ids = [row[0] for row in result.all()]
    
    for chat_id in chat_ids:
        manager.add_user_to_chat(user_id, chat_id)
```

---

### 2. ✅ Счетчик непрочитанных сообщений
**Проблема:** Счетчик не обновлялся при получении новых сообщений

**Решение:**
- Добавлено логирование для отладки счетчика
- Улучшена логика увеличения счетчика
- Добавлена проверка отправителя (не увеличивать для своих сообщений)

**Код:**
```javascript
// Увеличиваем счетчик непрочитанных
if (data.message.sender_id !== authStore.user?.id) {
  const currentCount = unreadMessages.value[data.chat_id] || 0
  unreadMessages.value[data.chat_id] = currentCount + 1
  console.log(`📊 Unread count for chat ${data.chat_id}: ${unreadMessages.value[data.chat_id]}`)
}
```

---

### 3. ✅ Новые сообщения поднимаются наверх
**Проблема:** Чаты с новыми сообщениями не перемещались наверх списка

**Решение:**
- Добавлена логика перемещения чата наверх при получении нового сообщения
- Обновляется last_message в чате
- Добавлено логирование

**Код:**
```javascript
// Перемещаем чат наверх
const index = chats.value.indexOf(chat)
if (index > 0) {
  chats.value.splice(index, 1)
  chats.value.unshift(chat)
  console.log(`⬆️ Moved chat ${data.chat_id} to top`)
}
```

---

### 4. ✅ Кнопка удаления чата на десктопе
**Проблема:** Кнопка удаления появлялась только при наведении

**Решение:**
- Добавлен класс `opacity-100` для постоянной видимости
- Кнопка теперь всегда видна на десктопе

**Код:**
```vue
<button
  @click.prevent="confirmDeleteChat(chat)"
  class="hidden lg:block absolute top-4 right-4 p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors opacity-100"
  title="Удалить чат"
>
  <TrashIcon class="w-5 h-5" />
</button>
```

---

## 🧪 Как протестировать

### Тест 1: WebSocket подключение
1. Откройте http://localhost:3000
2. Войдите в систему (admin / admin123)
3. Откройте консоль браузера (F12)
4. Проверьте логи:
   ```
   🔌 Connecting to WebSocket from ChatsView...
   ✅ WebSocket connected in ChatsView
   📡 Subscribing to WebSocket events in ChatsView
   ```

### Тест 2: Новые сообщения и счетчик
1. Откройте приложение в двух окнах:
   - Окно 1: user1 / password123
   - Окно 2: user2 / password123
2. В окне 1 отправьте сообщение user2
3. В окне 2 проверьте:
   - ✅ Чат переместился наверх
   - ✅ Появилось последнее сообщение
   - ✅ Появился красный бейдж с "1"
4. В консоли окна 2 должны быть логи:
   ```
   📨 New message in chat list: {...}
   📊 Unread count for chat X: 1
   ⬆️ Moved chat X to top
   ```

### Тест 3: Сброс счетчика
1. Откройте чат с непрочитанными сообщениями
2. Счетчик должен исчезнуть
3. В консоли:
   ```
   ✅ Messages read: {...}
   📊 Reset unread count for chat X
   ```

### Тест 4: Кнопка удаления на десктопе
1. Откройте /chats на десктопе (ширина > 1024px)
2. Наведите на любой чат
3. Кнопка удаления (корзина) должна быть видна всегда
4. Нажмите на кнопку
5. Подтвердите удаление
6. Чат должен исчезнуть из списка

### Тест 5: Свайп для удаления на мобильном
1. Откройте /chats на мобильном (или уменьшите окно)
2. Свайпните чат влево
3. Должна появиться красная кнопка удаления
4. Свайпните дальше (> 60px)
5. Появится подтверждение удаления

---

## 🐛 Отладка

### Проблема: WebSocket не подключается
**Проверка:**
```javascript
// В консоли браузера
websocket.isConnected()  // должно быть true
```

**Решение:**
1. Проверьте backend логи:
   ```bash
   docker logs chat_backend --tail 50 | grep WebSocket
   ```
2. Проверьте .env файл:
   ```bash
   cat frontend/.env
   # Должно быть: VITE_WS_URL=ws://localhost:8000
   ```
3. Перезапустите контейнеры:
   ```bash
   docker restart chat_backend chat_frontend
   ```

### Проблема: Счетчик не обновляется
**Проверка:**
```javascript
// В консоли браузера
console.log(unreadMessages.value)
```

**Решение:**
1. Проверьте WebSocket подключение (см. выше)
2. Проверьте логи в консоли:
   ```
   📨 New message in chat list: {...}
   📊 Unread count for chat X: Y
   ```
3. Если логов нет - проверьте backend:
   ```bash
   docker logs chat_backend --tail 50 | grep "new_message"
   ```

### Проблема: Чаты не перемещаются наверх
**Проверка:**
```javascript
// В консоли браузера должно быть:
⬆️ Moved chat X to top
```

**Решение:**
1. Убедитесь, что WebSocket подключен
2. Проверьте, что сообщение приходит:
   ```
   📨 New message in chat list: {...}
   ```
3. Если сообщение приходит, но чат не перемещается - очистите кэш браузера (Ctrl+Shift+R)

### Проблема: Кнопка удаления не видна
**Проверка:**
1. Откройте DevTools (F12)
2. Найдите элемент кнопки удаления
3. Проверьте CSS классы

**Решение:**
1. Убедитесь, что ширина окна > 1024px
2. Проверьте класс `opacity-100` на кнопке
3. Очистите кэш браузера

---

## 📊 Логирование

### Frontend (консоль браузера)
```
🔌 Connecting to WebSocket from ChatsView...
✅ WebSocket connected in ChatsView
📡 Subscribing to WebSocket events in ChatsView
📨 New message in chat list: {...}
📊 Unread count for chat X: Y
⬆️ Moved chat X to top
✅ Messages read: {...}
📊 Reset unread count for chat X
🔌 Unsubscribing from WebSocket events in ChatsView
```

### Backend (docker logs)
```bash
docker logs chat_backend --tail 50
```

Ищите:
```
INFO:     User X connected. Total connections: Y
INFO:     Added user X to chat Y
INFO:     Sending new_message notification for chat X to all members except Y
INFO:     Chat X has Y members
INFO:     Sent notification to user Z
```

---

## 🚀 Команды для обновления

### Пересборка frontend
```bash
docker exec chat_frontend npm run build
```

### Перезапуск контейнеров
```bash
docker restart chat_backend
docker restart chat_frontend
```

### Проверка статуса
```bash
docker-compose ps
```

### Просмотр логов
```bash
# Backend
docker logs chat_backend --tail 50 -f

# Frontend
docker logs chat_frontend --tail 50 -f
```

---

## ✅ Готово!

Все проблемы исправлены:
1. ✅ WebSocket работает корректно
2. ✅ Счетчик непрочитанных обновляется в реальном времени
3. ✅ Новые сообщения поднимаются наверх
4. ✅ Кнопка удаления всегда видна на десктопе

Откройте http://localhost:3000 и протестируйте все функции!

---

**Дата обновления:** 23.11.2025 02:56
