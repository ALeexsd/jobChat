# ⚡ Быстрая установка на VPS Ubuntu

## 🎯 За 5 минут до запуска

### Требования
- Ubuntu 20.04/22.04
- 4GB RAM минимум
- Домен с A-записью на IP сервера
- Root доступ по SSH

### Шаг 1: Подключение к серверу
```bash
ssh root@ваш-сервер-ip
```

### Шаг 2: Скачивание проекта
```bash
cd /tmp
git clone <repository-url> corporate-messenger
cd corporate-messenger
```

### Шаг 3: Запуск установки
```bash
chmod +x deploy-ubuntu.sh
sudo bash deploy-ubuntu.sh
```

**Скрипт запросит:**
- Ваш домен (например: chat.company.com)
- Email для SSL сертификата

### Шаг 4: Ожидание (10-15 минут)
Скрипт автоматически:
- ✅ Установит Docker и Docker Compose
- ✅ Установит Nginx
- ✅ Получит SSL сертификат
- ✅ Настроит Firewall
- ✅ Запустит приложение
- ✅ Создаст администратора

### Шаг 5: Готово! 🎉
Откройте в браузере: **https://ваш-домен.com**

**Данные для входа:**
- Логин: `admin`
- Пароль: `admin123`

⚠️ **Сразу смените пароль!**

---

## 🔧 Полезные команды

После установки доступны команды:

```bash
# Статус приложения
chat-status

# Просмотр логов
chat-logs

# Перезапуск
chat-restart

# Dashboard
chat-dashboard

# Проверка здоровья
chat-health

# Создать бэкап
chat-backup
```

---

## 📋 Что дальше?

### 1. Настройка мониторинга (опционально)
```bash
sudo bash monitoring-setup.sh ваш-email@example.com
```

Это настроит:
- Автоматические проверки каждые 5 минут
- Ежедневные отчеты на email
- Алерты при проблемах

### 2. Проверка работы
```bash
chat-health
```

### 3. Просмотр dashboard
```bash
chat-dashboard
```

---

## 🆘 Проблемы?

### Контейнеры не запускаются
```bash
cd /opt/corporate-messenger
docker-compose -f docker-compose.prod.yml logs
```

### SSL не работает
```bash
sudo certbot certificates
sudo certbot renew
sudo systemctl restart nginx
```

### Приложение недоступно
```bash
# Проверка портов
sudo netstat -tlnp | grep -E "80|443"

# Проверка Nginx
sudo nginx -t
sudo systemctl status nginx

# Перезапуск всего
chat-restart
```

---

## 📚 Документация

Подробная документация:
- [INSTALL_VPS.md](INSTALL_VPS.md) - Полная инструкция
- [DEPLOYMENT.md](DEPLOYMENT.md) - Production развертывание
- [README.md](README.md) - Общая информация

---

## 🔒 Безопасность

После установки обязательно:

1. ✅ Смените пароль администратора
2. ✅ Измените SECRET_KEY в `/opt/corporate-messenger/backend/.env`
3. ✅ Измените пароль PostgreSQL
4. ✅ Настройте регулярные бэкапы (уже настроены автоматически)
5. ✅ Установите Fail2Ban (опционально):
   ```bash
   sudo apt install fail2ban -y
   ```

---

## 📊 Мониторинг

### Быстрая проверка
```bash
# Статус контейнеров
docker ps

# Использование ресурсов
docker stats

# Логи
chat-logs
```

### Dashboard
```bash
chat-dashboard
```

### Полная проверка здоровья
```bash
chat-health ваш-домен.com
```

---

## 🔄 Обновление

```bash
cd /opt/corporate-messenger
sudo bash update-app.sh
```

---

## 💾 Бэкапы

### Создать бэкап вручную
```bash
chat-backup
```

### Восстановить из бэкапа
```bash
cd /opt/corporate-messenger
sudo bash restore-backup.sh backups/backup_20240101_120000.sql.gz
```

### Автоматические бэкапы
Уже настроены! Создаются каждый день в 2:00 ночи.

Хранятся в: `/opt/corporate-messenger/backups/`

---

## 📞 Поддержка

Если что-то пошло не так:

1. Проверьте логи: `chat-logs`
2. Проверьте статус: `chat-status`
3. Проверьте здоровье: `chat-health`
4. Посмотрите документацию: [INSTALL_VPS.md](INSTALL_VPS.md)
5. Создайте issue в GitHub

---

**Готово!** Ваш корпоративный мессенджер работает! 🚀
