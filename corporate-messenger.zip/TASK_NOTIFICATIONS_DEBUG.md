# 🐛 Отладка уведомлений о задачах

## Добавлено логирование

Я добавил подробное логирование для отладки проблемы с уведомлениями.

## Как проверить

### 1. Перезапустите бэкенд

```bash
cd backend
# Остановите текущий процесс (Ctrl+C)
# Запустите снова
python -m uvicorn app.main:app --reload
```

### 2. Откройте консоль браузера (F12)

В консоли должны появиться сообщения:
```
📋 TasksView: Subscribing to task_assigned events
📋 TasksView: WebSocket connected: true
```

### 3. Создайте задачу и назначьте кому-то

#### В консоли браузера (получатель) должно появиться:
```
📨 WebSocket message received: task_assigned { type: "task_assigned", task_id: 123, ... }
🎯 TasksView: Task assigned event received! { ... }
🔔 Showing browser notification
🔊 Playing sound
🔄 Reloading tasks
```

#### В логах бэкенда должно появиться:
```
📋 Sending task notifications to 1 assignees
📋 Sending notification to user 2 for task 123
📋 Preparing to send task notification to user 2
📋 User 2 online: True
📋 Message: {'type': 'task_assigned', 'task_id': 123, ...}
✅ Sent task notification to user 2 for task 123
```

## Возможные проблемы и решения

### Проблема 1: WebSocket не подключен
**Симптом:** В консоли `WebSocket connected: false`

**Решение:**
1. Проверьте, что бэкенд запущен
2. Проверьте URL WebSocket в `.env`:
   ```
   VITE_WS_URL=ws://localhost:8000
   ```
3. Проверьте, что пользователь авторизован

### Проблема 2: Пользователь не онлайн
**Симптом:** В логах бэкенда `User X online: False`

**Решение:**
1. Убедитесь, что получатель открыл приложение
2. Проверьте, что WebSocket подключен у получателя
3. Откройте консоль у получателя и проверьте сообщение "WebSocket connection established"

### Проблема 3: Событие не приходит на фронтенд
**Симптом:** Бэкенд отправляет, но фронтенд не получает

**Решение:**
1. Проверьте, что обработчик зарегистрирован:
   ```javascript
   // В консоли должно быть:
   📋 TasksView: Subscribing to task_assigned events
   ```
2. Проверьте, что страница TasksView открыта
3. Попробуйте обновить страницу

### Проблема 4: Браузерные уведомления не показываются
**Симптом:** Событие приходит, но уведомление не показывается

**Решение:**
1. Проверьте разрешения браузера:
   ```javascript
   console.log(Notification.permission) // должно быть "granted"
   ```
2. Если "denied" или "default", запросите разрешение:
   - Откройте настройки сайта в браузере
   - Разрешите уведомления
   - Или добавьте код запроса разрешения в ProfileView

### Проблема 5: Звук не воспроизводится
**Симптом:** Уведомление показывается, но звука нет

**Решение:**
1. Проверьте, что файлы звуков есть в `frontend/public/sounds/`
2. Проверьте настройки звука в профиле пользователя
3. Проверьте консоль на ошибки воспроизведения

## Тестовый сценарий

### Шаг 1: Подготовка
1. Откройте два браузера (или два окна инкогнито)
2. Войдите как Пользователь 1 в первом браузере
3. Войдите как Пользователь 2 во втором браузере

### Шаг 2: Проверка подключения
В обоих браузерах откройте консоль (F12) и проверьте:
```
✅ WebSocket connection established
✅ WebSocket connected: true
```

### Шаг 3: Создание задачи
В первом браузере (Пользователь 1):
1. Перейдите в "Задачи"
2. Нажмите "Новая задача"
3. Заполните форму
4. Назначьте задачу Пользователю 2
5. Сохраните

### Шаг 4: Проверка получения
Во втором браузере (Пользователь 2):
1. Откройте консоль (F12)
2. Должны увидеть логи:
   ```
   📨 WebSocket message received: task_assigned
   🎯 TasksView: Task assigned event received!
   ```
3. Должно появиться браузерное уведомление
4. Должен прозвучать звук
5. Задача должна появиться в списке

### Шаг 5: Проверка бэкенда
В терминале бэкенда должны быть логи:
```
📋 Sending task notifications to 1 assignees
📋 Sending notification to user 2 for task X
📋 Preparing to send task notification to user 2
📋 User 2 online: True
✅ Sent task notification to user 2 for task X
```

## Если ничего не помогло

1. **Перезапустите бэкенд:**
   ```bash
   cd backend
   # Ctrl+C
   python -m uvicorn app.main:app --reload
   ```

2. **Очистите кэш браузера:**
   - Ctrl+Shift+Delete
   - Очистите кэш и cookies
   - Перезагрузите страницу

3. **Проверьте версию кода:**
   - Убедитесь, что все файлы сохранены
   - Проверьте, что фронтенд пересобрался (HMR)

4. **Проверьте логи:**
   - Бэкенд: смотрите терминал
   - Фронтенд: смотрите консоль браузера (F12)

## Полезные команды для отладки

### Проверить WebSocket подключение в консоли браузера:
```javascript
// Проверить статус
websocket.isConnected()

// Отправить тестовое сообщение
websocket.send({ type: 'ping' })

// Посмотреть все обработчики
console.log(websocket.messageHandlers)
```

### Проверить онлайн пользователей на бэкенде:
Добавьте endpoint в `backend/app/api/debug.py`:
```python
@router.get("/online-users")
async def get_online_users():
    from app.websocket.manager import manager
    return {"online_users": manager.get_online_users()}
```

## Успешная отладка ✅

Если все работает, вы должны видеть:
- ✅ Логи на бэкенде об отправке уведомления
- ✅ Логи на фронтенде о получении события
- ✅ Браузерное уведомление
- ✅ Звуковой сигнал
- ✅ Обновление списка задач

Удачи! 🚀
