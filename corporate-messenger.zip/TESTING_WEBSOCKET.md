# 🧪 Тестирование WebSocket

## Шаг 1: Откройте приложение

1. Откройте http://localhost:3000 в браузере
2. Нажмите F12 для открытия консоли разработчика
3. Войдите как **admin / admin123**

## Шаг 2: Проверьте логи подключения

В консоли должны появиться следующие логи:

```
🔌 WebSocket connect() called
Current state: undefined
Is connecting: false
🔗 Connecting to WebSocket: ws://localhost:8000/ws?token=...
Token (first 20 chars): eyJhbGciOiJIUzI1NiIs...
✅ WebSocket onopen fired - connection established!
📨 WebSocket message received: connected {...}
```

### Если логов нет:

**Проблема 1: Нет лога "🔌 WebSocket connect() called"**
- WebSocket вообще не вызывается
- Проверьте, что вы на странице /chats

**Проблема 2: Есть лог "❌ No access token available"**
- Токен не сохранен
- Выйдите и войдите снова

**Проблема 3: Есть лог "❌ WebSocket error fired"**
- Backend не отвечает
- Проверьте: `docker ps | grep chat_backend`

## Шаг 3: Проверьте подключение вручную

В консоли браузера выполните:

```javascript
// Проверка состояния WebSocket
import websocket from '@/services/websocket'
console.log('Connected:', websocket.isConnected())
console.log('WebSocket state:', websocket.ws?.readyState)
// 0 = CONNECTING, 1 = OPEN, 2 = CLOSING, 3 = CLOSED
```

Должно быть:
```
Connected: true
WebSocket state: 1
```

## Шаг 4: Тест отправки сообщения

### Подготовка:
1. Откройте **два окна** браузера (или два разных браузера)
2. В первом окне войдите как **user1 / password123**
3. Во втором окне войдите как **user2 / password123**
4. В обоих окнах откройте консоль (F12)

### В первом окне (user1):
1. Перейдите в /chats
2. Найдите чат с user2 (или создайте новый)
3. Откройте чат
4. Отправьте сообщение: "Тест WebSocket"

### Во втором окне (user2):
1. Перейдите в /chats
2. **НЕ ОТКРЫВАЙТЕ** чат с user1
3. Смотрите на консоль

### Ожидаемый результат во втором окне:

**В консоли:**
```
📨 WebSocket message received: new_message {...}
📨 New message in chat list: {chat_id: X, message: {...}}
📊 Unread count for chat X: 1
⬆️ Moved chat X to top
```

**На странице:**
- Чат с user1 переместился наверх списка
- Появилось последнее сообщение "Тест WebSocket"
- Появился красный бейдж с цифрой "1"

### Если ничего не произошло:

**Проверка 1: WebSocket подключен?**
```javascript
websocket.isConnected()  // должно быть true
```

**Проверка 2: Backend отправляет уведомления?**
```bash
docker logs chat_backend -f
```

Должны быть логи:
```
INFO: Sending new_message notification for chat X to all members except Y
INFO: Chat X has 2 members
INFO: Sent notification to user Z
```

**Проверка 3: Frontend получает сообщения?**
В консоли должен быть лог:
```
📨 WebSocket message received: new_message {...}
```

Если этого лога нет - сообщение не доходит до frontend.

## Шаг 5: Проверка счетчика

### Во втором окне (user2):
1. Не открывайте чат
2. Попросите user1 отправить еще 2 сообщения
3. Счетчик должен показывать "3"

### Откройте чат:
1. Кликните на чат с user1
2. Счетчик должен исчезнуть
3. В консоли должен быть лог:
```
✅ Messages read: {chat_id: X, user_id: Y}
📊 Reset unread count for chat X
```

## Шаг 6: Backend логи

Откройте терминал и выполните:

```bash
docker logs chat_backend -f
```

При подключении пользователя должны появиться:
```
INFO: User X connected. Total connections: Y
INFO: Added user X to chat Z
```

При отправке сообщения:
```
INFO: Sending new_message notification for chat X to all members except Y
INFO: Chat X has 2 members
INFO: Sent notification to user Z
```

## Решение проблем

### WebSocket не подключается

**Решение 1: Перезапуск**
```bash
docker-compose restart
```

**Решение 2: Проверка .env**
```bash
cat frontend/.env
```

Должно быть:
```
VITE_WS_URL=ws://localhost:8000
```

**Решение 3: Очистка кэша**
- Ctrl+Shift+R в браузере

### Сообщения не доходят

**Решение 1: Проверка backend**
```bash
docker logs chat_backend --tail 100 | grep "new_message"
```

Если нет логов - backend не отправляет уведомления.

**Решение 2: Проверка frontend**
В консоли браузера:
```javascript
// Подписка на все события
websocket.on('*', (data) => console.log('📨 Any message:', data))
```

**Решение 3: Перезапуск WebSocket**
В консоли браузера:
```javascript
websocket.disconnect()
setTimeout(() => websocket.connect(), 1000)
```

### Счетчик не работает

**Проверка 1: Данные приходят?**
В консоли должен быть лог:
```
📊 Unread count for chat X: Y
```

**Проверка 2: Reactive переменная?**
```javascript
console.log(unreadMessages.value)
```

**Решение: Перезагрузка страницы**
- F5 или Ctrl+R

## Итоговая проверка

Если все работает правильно, вы должны видеть:

✅ WebSocket подключается при входе
✅ Логи в консоли при подключении
✅ Новые сообщения появляются в реальном времени
✅ Чаты перемещаются наверх
✅ Счетчик непрочитанных обновляется
✅ Счетчик сбрасывается при открытии чата

---

**Следующий шаг:** Откройте http://localhost:3000 и выполните тесты выше.

Если что-то не работает - скопируйте логи из консоли и backend, и мы разберемся!
