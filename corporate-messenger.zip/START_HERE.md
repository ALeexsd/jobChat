# 🚀 НАЧНИТЕ ЗДЕСЬ - Установка на VPS Ubuntu

## ⚡ Что это?

Полный набор для развертывания корпоративного мессенджера на VPS с Ubuntu.

**Всё автоматизировано. Установка за 10 минут.**

## 🎯 Что вам нужно?

- ✅ VPS с Ubuntu 20.04/22.04 (минимум 4GB RAM)
- ✅ Домен с A-записью на IP сервера
- ✅ Email для SSL сертификата
- ✅ 10 минут времени

**Стоимость:** от $10-15/месяц

## 🚀 Установка (3 команды)

```bash
# 1. Подключитесь к серверу
ssh root@ваш-сервер-ip

# 2. Скачайте проект
cd /tmp
git clone <repository-url> corporate-messenger
cd corporate-messenger

# 3. Запустите установку
chmod +x deploy-ubuntu.sh
sudo bash deploy-ubuntu.sh
```

**Скрипт спросит:**
- Ваш домен (например: chat.company.com)
- Email для SSL

**Всё остальное - автоматически!**

## ✅ Готово!

Через 10-15 минут откройте: **https://ваш-домен.com**

**Войдите:**
- Логин: `admin`
- Пароль: `admin123`

⚠️ **Сразу смените пароль!**

## 📚 Что дальше?

### Быстрый старт
👉 [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md) - Подробная инструкция за 5 минут

### Полное руководство
👉 [README_VPS.md](README_VPS.md) - Всё про установку и управление

### Выбор VPS
👉 [VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md) - Какой VPS выбрать?

### Команды
👉 [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md) - Все команды

### Навигация
👉 [VPS_INDEX.md](VPS_INDEX.md) - Полный индекс документации

## 🔧 Основные команды

После установки доступны:

```bash
chat-status      # Статус приложения
chat-logs        # Логи
chat-restart     # Перезапуск
chat-health      # Проверка здоровья
chat-dashboard   # Dashboard
chat-backup      # Создать бэкап
```

## 🆘 Проблемы?

```bash
# Быстрая диагностика
chat-health

# Логи
chat-logs

# Перезапуск
chat-restart
```

**Не помогло?** Смотрите [README_VPS.md](README_VPS.md) → раздел "Решение проблем"

## 📋 Чеклист

- [ ] VPS создан (Ubuntu 22.04, 4GB RAM)
- [ ] Домен настроен (A-запись → IP сервера)
- [ ] Запущен `deploy-ubuntu.sh`
- [ ] Сайт открывается по HTTPS
- [ ] Вход работает (admin/admin123)
- [ ] Пароль изменен
- [ ] Всё работает!

## 💡 Рекомендуемые провайдеры VPS

| Провайдер | Цена | Конфигурация | Ссылка |
|-----------|------|--------------|--------|
| **Hetzner** | €5.83/мес | 2 CPU, 4GB RAM | hetzner.com |
| **DigitalOcean** | $12/мес | 2 CPU, 4GB RAM | digitalocean.com |
| **Vultr** | $12/мес | 2 CPU, 4GB RAM | vultr.com |

Подробнее: [VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md)

## 🎓 Уровни документации

### Новичок
1. **START_HERE.md** ← Вы здесь
2. [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md)
3. [VPS_CHECKLIST.md](VPS_CHECKLIST.md)

### Опытный
1. [README_VPS.md](README_VPS.md)
2. [INSTALL_VPS.md](INSTALL_VPS.md)
3. [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md)

### Эксперт
1. [DEPLOYMENT.md](DEPLOYMENT.md)
2. [ARCHITECTURE.md](ARCHITECTURE.md)
3. Исходный код

## 🔒 Безопасность

После установки **обязательно**:

1. ✅ Смените пароль администратора
2. ✅ Измените SECRET_KEY в `/opt/corporate-messenger/backend/.env`
3. ✅ Измените пароль PostgreSQL

Подробнее: [README_VPS.md](README_VPS.md) → раздел "Безопасность"

## 📊 Что устанавливается?

- ✅ Docker + Docker Compose
- ✅ Nginx (reverse proxy)
- ✅ SSL сертификат (Let's Encrypt)
- ✅ PostgreSQL 15
- ✅ Backend (FastAPI)
- ✅ Frontend (Vue.js)
- ✅ Автоматические бэкапы
- ✅ Firewall (UFW)

## 🎉 Готово к установке?

### Вариант 1: Автоматическая установка (рекомендуется)

```bash
ssh root@ваш-сервер-ip
cd /tmp && git clone <repo> corporate-messenger && cd corporate-messenger
chmod +x deploy-ubuntu.sh && sudo bash deploy-ubuntu.sh
```

### Вариант 2: Пошаговая инструкция

Следуйте [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md)

### Вариант 3: Ручная установка

Следуйте [INSTALL_VPS.md](INSTALL_VPS.md)

## 📞 Нужна помощь?

1. **Документация:** [VPS_INDEX.md](VPS_INDEX.md) - полный индекс
2. **Команды:** [COMMANDS_REFERENCE.md](COMMANDS_REFERENCE.md)
3. **Проблемы:** [README_VPS.md](README_VPS.md) → "Решение проблем"
4. **GitHub:** Создайте issue

## ⏱️ Сколько времени?

- **Подготовка VPS:** 5 минут
- **Настройка домена:** 5 минут (+ время DNS)
- **Установка:** 10-15 минут
- **Проверка:** 5 минут
- **Настройка безопасности:** 10 минут

**Итого: 35-40 минут**

## 💰 Сколько стоит?

### Минимальная конфигурация
- VPS: $10-15/месяц
- Домен: $10/год (~$1/месяц)
- SSL: Бесплатно
- **Итого: ~$11-16/месяц**

### Рекомендуемая конфигурация
- VPS: $25-40/месяц
- Домен: $10/год (~$1/месяц)
- SSL: Бесплатно
- **Итого: ~$26-41/месяц**

Подробнее: [VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md)

## 🌟 Особенности

- ✅ Полная автоматизация установки
- ✅ HTTPS из коробки
- ✅ Автоматические бэкапы
- ✅ Мониторинг и алерты
- ✅ Простое управление
- ✅ Подробная документация
- ✅ Быстрое обновление
- ✅ Легкое восстановление

## 🚦 Следующий шаг

**Готовы начать?**

1. Создайте VPS
2. Настройте домен
3. Запустите `deploy-ubuntu.sh`
4. Готово!

**Нужно больше информации?**

Читайте [README_VPS.md](README_VPS.md) или [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md)

---

**Удачной установки! 🚀**

Если возникнут вопросы - вся документация в [VPS_INDEX.md](VPS_INDEX.md)
