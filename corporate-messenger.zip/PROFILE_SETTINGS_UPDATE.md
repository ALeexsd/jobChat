# ✅ Добавление настроек статуса в профиль

## 🎯 Что добавлено

### 1. Настройки статуса в профиле пользователя

#### Новый раздел "Настройки":
- 🟢 **Онлайн** - пользователь активен
- 🟡 **Отошел** - пользователь временно отсутствует
- ⚪ **Оффлайн** - пользователь не в сети

#### Функционал:
- ✅ Выпадающий список для выбора статуса
- ✅ Автоматическое обновление при изменении
- ✅ Статус виден всем пользователям
- ✅ Подсказка о видимости статуса

---

## 📋 Изменения в коде

### Frontend (`frontend/src/views/ProfileView.vue`)

#### Добавлен раздел настроек:
```vue
<div class="card dark:bg-gray-800 dark:border-gray-700 p-6">
  <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
    Настройки
  </h3>
  <div class="space-y-4">
    <div>
      <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
        Статус
      </label>
      <select
        v-model="profileData.status"
        @change="handleUpdateStatus"
        class="input bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
      >
        <option value="online">🟢 Онлайн</option>
        <option value="away">🟡 Отошел</option>
        <option value="offline">⚪ Оффлайн</option>
      </select>
      <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
        Ваш статус виден другим пользователям
      </p>
    </div>
  </div>
</div>
```

#### Функция обновления статуса:
```javascript
async function handleUpdateStatus() {
  try {
    await api.put('/users/me', { status: profileData.value.status })
    await authStore.checkAuth()
  } catch (error) {
    console.error('Update status error:', error)
    alert('Ошибка обновления статуса')
  }
}
```

#### Инициализация статуса:
```javascript
profileData.value = {
  first_name: user.value.first_name || '',
  last_name: user.value.last_name || '',
  email: user.value.email || '',
  position: user.value.position || '',
  phone: phone,
  status: user.value.status || 'online'  // ← Добавлено
}
```

---

## 🔧 Исправление цветовой схемы

### Проблема:
Цветовая схема статусов не работала из-за отсутствия поля `status` в базе данных для некоторых пользователей.

### Решение:
1. ✅ Создана миграция базы данных
2. ✅ Применена миграция `ensure_user_status_field`
3. ✅ Все пользователи теперь имеют поле `status`
4. ✅ Значение по умолчанию: `offline`

### Миграция:
```bash
docker exec chat_backend alembic revision --autogenerate -m "ensure_user_status_field"
docker exec chat_backend alembic upgrade head
```

---

## 🎨 Отображение статусов

### 1. Список сотрудников (`/employees`)
```vue
<!-- Маленькая точка рядом с именем -->
<div :class="[
  'w-2 h-2 rounded-full',
  employee.status === 'online' ? 'bg-green-500' : 
  employee.status === 'away' ? 'bg-yellow-500' : 
  'bg-gray-400'
]" :title="getStatusLabel(employee.status)"></div>
```

**Результат:**
```
Иван Иванов 🟢
@ivan • Менеджер
```

---

### 2. Список пользователей (`/users`)
```vue
<!-- Индикатор на аватаре -->
<div :class="[
  'absolute bottom-0 right-0 w-4 h-4 rounded-full border-2 border-white',
  user.status === 'online' ? 'bg-green-500' : 
  user.status === 'away' ? 'bg-yellow-500' : 
  'bg-gray-400'
]"></div>

<!-- Текстовый бейдж -->
<span :class="[
  'text-xs px-2 py-0.5 rounded-full',
  user.status === 'online' ? 'bg-green-100 text-green-800' : 
  user.status === 'away' ? 'bg-yellow-100 text-yellow-800' : 
  'bg-gray-100 text-gray-800'
]">
  {{ getStatusLabel(user.status) }}
</span>
```

**Результат:**
```
┌─────────────────────────────────┐
│ 👤🟢 Иван Иванов [Онлайн]       │
│     ivan@example.com            │
│     Менеджер                    │
└─────────────────────────────────┘
```

---

### 3. Профиль пользователя (`/profile`)
```vue
<select v-model="profileData.status" @change="handleUpdateStatus">
  <option value="online">🟢 Онлайн</option>
  <option value="away">🟡 Отошел</option>
  <option value="offline">⚪ Оффлайн</option>
</select>
```

**Результат:**
```
┌─────────────────────────────────┐
│ Настройки                       │
│                                 │
│ Статус                          │
│ [🟢 Онлайн ▼]                   │
│                                 │
│ Ваш статус виден другим         │
│ пользователям                   │
└─────────────────────────────────┘
```

---

## 📊 Цветовая схема

| Статус | Emoji | Цвет точки | Цвет бейджа | Текст |
|--------|-------|------------|-------------|-------|
| online | 🟢 | `bg-green-500` | `bg-green-100 text-green-800` | Онлайн |
| away | 🟡 | `bg-yellow-500` | `bg-yellow-100 text-yellow-800` | Отошел |
| offline | ⚪ | `bg-gray-400` | `bg-gray-100 text-gray-800` | Оффлайн |

### Dark Mode:
| Статус | Цвет бейджа (темная тема) |
|--------|---------------------------|
| online | `bg-green-900 text-green-200` |
| away | `bg-yellow-900 text-yellow-200` |
| offline | `bg-gray-700 text-gray-200` |

---

## 🔄 API

### Обновление статуса:
```http
PUT /users/me
Content-Type: application/json

{
  "status": "online"
}
```

### Ответ:
```json
{
  "id": 1,
  "username": "ivan",
  "first_name": "Иван",
  "last_name": "Иванов",
  "email": "ivan@example.com",
  "position": "Менеджер",
  "role": "employee",
  "status": "online",
  "avatar_url": "/uploads/avatars/1.jpg",
  "last_seen": "2025-11-22T12:00:00",
  "is_active": true,
  "created_at": "2025-01-01T00:00:00"
}
```

---

## 📱 Использование

### Изменение статуса:
1. Открыть профиль: `http://localhost:3000/profile`
2. Найти раздел "Настройки"
3. Выбрать нужный статус из выпадающего списка
4. Статус обновится автоматически

### Просмотр статусов других пользователей:
1. **Сотрудники** (`/employees`) - точка рядом с именем
2. **Пользователи** (`/users`) - индикатор на аватаре + бейдж
3. **Чаты** - статус в списке участников

---

## ✅ Проверка работы

### 1. Изменение статуса:
```
1. Открыть /profile
2. Найти раздел "Настройки"
3. Изменить статус на "Отошел"
4. Проверить, что статус сохранился
```

### 2. Отображение статуса:
```
1. Открыть /employees
2. Проверить цвет точки рядом с именем
3. Открыть /users
4. Проверить индикатор на аватаре
5. Проверить текстовый бейдж
```

### 3. Цветовая схема:
```
1. Установить статус "Онлайн" → 🟢 зеленый
2. Установить статус "Отошел" → 🟡 желтый
3. Установить статус "Оффлайн" → ⚪ серый
```

---

## 🚀 Обновление

Контейнеры перезапущены:
```bash
docker restart chat_backend chat_frontend
```

Миграция применена:
```bash
docker exec chat_backend alembic upgrade head
```

Все изменения применены и работают! ✅

---

## 🎯 Итог

### Добавлено:
- ✅ Раздел "Настройки" в профиле
- ✅ Выбор статуса (онлайн/отошел/оффлайн)
- ✅ Автоматическое обновление статуса
- ✅ Корректное отображение цветов

### Исправлено:
- ✅ Цветовая схема статусов теперь работает
- ✅ Миграция базы данных применена
- ✅ Все пользователи имеют поле `status`

### Работает:
- ✅ Изменение статуса в профиле
- ✅ Отображение в списке сотрудников
- ✅ Отображение в списке пользователей
- ✅ Цветовая индикация (зеленый/желтый/серый)
