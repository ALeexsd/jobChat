# 📝 Обновление регистрации и профиля

## ✅ Что изменено

### 1. Упрощена регистрация

**Было:**
- Имя
- Фамилия
- Username
- Email
- Пароль
- Должность

**Стало:**
- Username
- Пароль
- Подтверждение пароля

**Преимущества:**
- ✅ Быстрая регистрация
- ✅ Минимум полей
- ✅ Меньше барьеров для входа
- ✅ Данные заполняются в профиле по желанию

---

### 2. Расширен профиль

**Добавлено:**
- ✅ Имя (необязательно)
- ✅ Фамилия (необязательно)
- ✅ Email (необязательно)
- ✅ Должность (необязательно)
- ✅ Телефон с валидацией (необязательно)

**Особенности телефона:**
- Формат: `+7 9XX XXX XX XX`
- Ввод: только 9 цифр без 8
- Валидация: должен начинаться с 9
- Автоформатирование: добавляется +7 автоматически

---

## 📱 Поле телефона

### Формат ввода:
```
Пользователь вводит: 912345678
Сохраняется в БД:     +7912345678
Отображается:         +7 912345678
```

### Валидация:
- ✅ Только цифры
- ✅ Ровно 9 цифр
- ✅ Должен начинаться с 9
- ✅ Автоматическое удаление нецифровых символов

### Пример:
```vue
<div class="flex items-center">
  <span class="px-3 py-2 bg-gray-100 border border-r-0 border-gray-300 rounded-l-lg">
    +7
  </span>
  <input
    v-model="profileData.phone"
    type="tel"
    maxlength="9"
    pattern="[0-9]{9}"
    class="input rounded-l-none"
    placeholder="912345678"
  />
</div>
```

---

## 🔄 Процесс регистрации

### Шаг 1: Регистрация
1. Пользователь вводит:
   - Username: `ivan`
   - Пароль: `123456`
   - Подтверждение: `123456`

2. Нажимает "Зарегистрироваться"

3. Создается пользователь с:
   - username: `ivan`
   - first_name: `ivan` (по умолчанию)
   - last_name: `` (пусто)

### Шаг 2: Вход
1. Пользователь входит с username и паролем

### Шаг 3: Заполнение профиля (по желанию)
1. Переходит в профиль
2. Заполняет:
   - Имя: `Иван`
   - Фамилия: `Иванов`
   - Email: `ivan@example.com`
   - Должность: `Менеджер`
   - Телефон: `912345678`

3. Нажимает "Сохранить изменения"

---

## 💻 Код изменений

### RegisterView.vue

**Форма:**
```vue
<form @submit.prevent="handleRegister" class="space-y-4">
  <div>
    <label>Имя пользователя</label>
    <input v-model="formData.username" required />
  </div>
  
  <div>
    <label>Пароль</label>
    <input v-model="formData.password" type="password" minlength="6" required />
  </div>
  
  <div>
    <label>Подтвердите пароль</label>
    <input v-model="formData.confirm_password" type="password" required />
  </div>
  
  <button type="submit">Зарегистрироваться</button>
</form>
```

**Валидация:**
```javascript
async function handleRegister() {
  if (formData.value.password !== formData.value.confirm_password) {
    error.value = 'Пароли не совпадают'
    return
  }
  
  if (formData.value.password.length < 6) {
    error.value = 'Пароль должен быть минимум 6 символов'
    return
  }
  
  await authStore.register({
    username: formData.value.username,
    password: formData.value.password,
    first_name: formData.value.username, // По умолчанию
    last_name: ''
  })
}
```

### ProfileView.vue

**Поле телефона:**
```vue
<div>
  <label>
    Телефон
    <span class="text-xs text-gray-500">(9 цифр без 8)</span>
  </label>
  <div class="flex items-center">
    <span class="px-3 py-2 bg-gray-100 border border-r-0 rounded-l-lg">
      +7
    </span>
    <input
      v-model="profileData.phone"
      type="tel"
      maxlength="9"
      pattern="[0-9]{9}"
      placeholder="912345678"
      @input="validatePhone"
    />
  </div>
  <p v-if="phoneError" class="text-red-600 text-sm">{{ phoneError }}</p>
</div>
```

**Валидация телефона:**
```javascript
function validatePhone() {
  const phone = profileData.value.phone
  
  // Удаляем все нецифровые символы
  profileData.value.phone = phone.replace(/\D/g, '')
  
  if (profileData.value.phone && profileData.value.phone.length !== 9) {
    phoneError.value = 'Номер должен содержать 9 цифр'
  } else if (profileData.value.phone && !profileData.value.phone.startsWith('9')) {
    phoneError.value = 'Номер должен начинаться с 9'
  } else {
    phoneError.value = ''
  }
}
```

**Сохранение:**
```javascript
async function handleUpdateProfile() {
  if (phoneError.value) {
    alert('Исправьте ошибки в форме')
    return
  }
  
  const dataToSend = {
    ...profileData.value,
    phone: profileData.value.phone ? `+7${profileData.value.phone}` : null
  }
  
  await api.put('/users/me', dataToSend)
}
```

---

## 🧪 Тестирование

### 1. Регистрация
```
1. Откройте http://localhost:3000/register
2. Введите:
   - Username: testuser2
   - Пароль: 123456
   - Подтверждение: 123456
3. Нажмите "Зарегистрироваться"
4. Должны перейти на страницу входа
```

### 2. Вход
```
1. Введите:
   - Username: testuser2
   - Пароль: 123456
2. Нажмите "Войти"
3. Должны попасть в приложение
```

### 3. Заполнение профиля
```
1. Перейдите в профиль (внизу sidebar)
2. Заполните поля:
   - Имя: Иван
   - Фамилия: Иванов
   - Email: ivan@test.com
   - Должность: Менеджер
   - Телефон: 912345678
3. Нажмите "Сохранить изменения"
4. Проверьте, что данные сохранились
```

### 4. Валидация телефона
```
Попробуйте ввести:
- 812345678 → Ошибка: "Номер должен начинаться с 9"
- 91234567  → Ошибка: "Номер должен содержать 9 цифр"
- 9123456789 → Обрезается до 9 цифр
- 912345678 → ✅ Правильно
```

---

## ✅ Преимущества

### Для пользователей:
- ✅ Быстрая регистрация (2 поля)
- ✅ Меньше барьеров для входа
- ✅ Заполнение профиля по желанию
- ✅ Понятная валидация телефона

### Для системы:
- ✅ Меньше обязательных полей
- ✅ Больше регистраций
- ✅ Данные заполняются постепенно
- ✅ Валидация на клиенте

---

## 📊 Сравнение

| Параметр | Было | Стало |
|----------|------|-------|
| Полей в регистрации | 6 | 3 |
| Обязательных полей | 5 | 2 |
| Время регистрации | ~2 мин | ~30 сек |
| Барьер входа | Высокий | Низкий |
| Заполнение профиля | При регистрации | По желанию |

---

## 🎉 Готово!

Регистрация упрощена, профиль расширен, телефон с валидацией добавлен!
