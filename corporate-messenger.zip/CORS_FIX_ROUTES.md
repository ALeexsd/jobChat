# 🔧 Исправление CORS ошибки для маршрутов

## Проблема

```
Access to XMLHttpRequest at 'http://localhost:8000/api/routes/' from origin 'http://localhost:3000' 
has been blocked by CORS policy: No 'Access-Control-Allow-Origin' header is present on the requested resource.
```

## Причины

1. Бэкенд не запущен на порту 8000
2. Фронтенд работает на порту 3000 вместо 5173
3. Неправильная конфигурация URL

## Решение

### 1. Проверьте, что бэкенд запущен

```bash
cd backend
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Должно появиться:
```
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
```

### 2. Проверьте URL бэкенда

Откройте в браузере: http://localhost:8000/docs

Должна открыться документация API (Swagger UI).

### 3. Проверьте конфигурацию фронтенда

Создайте файл `frontend/.env` (если его нет):

```env
VITE_API_URL=http://localhost:8000/api
VITE_WS_URL=ws://localhost:8000
```

### 4. Перезапустите фронтенд

```bash
cd frontend
npm run dev
```

### 5. Проверьте порт фронтенда

Фронтенд должен запуститься на порту 5173 (по умолчанию для Vite):
```
VITE v5.x.x  ready in xxx ms

➜  Local:   http://localhost:5173/
➜  Network: use --host to expose
```

Если запущен на порту 3000, проверьте конфигурацию Vite.

## Альтернативное решение

Если фронтенд работает на порту 3000, обновите CORS на бэкенде:

### backend/app/main.py

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",  # Добавьте порт 3000
        "http://localhost:5173",
        "http://localhost:8080"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
    max_age=3600
)
```

## Проверка

### 1. Откройте консоль браузера (F12)

### 2. Попробуйте создать маршрут

### 3. Проверьте Network tab

Должен быть успешный запрос:
```
POST http://localhost:8000/api/routes/
Status: 200 OK
```

### 4. Если ошибка CORS осталась

Проверьте логи бэкенда:
```bash
# В терминале бэкенда должны быть запросы:
INFO:     127.0.0.1:xxxxx - "OPTIONS /api/routes/ HTTP/1.1" 200 OK
INFO:     127.0.0.1:xxxxx - "POST /api/routes/ HTTP/1.1" 200 OK
```

## Быстрая проверка

### Тест 1: Проверка бэкенда
```bash
curl http://localhost:8000/health
```

Должно вернуть:
```json
{"status":"healthy"}
```

### Тест 2: Проверка API
```bash
curl http://localhost:8000/api/routes/ \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Тест 3: Проверка CORS
```bash
curl -X OPTIONS http://localhost:8000/api/routes/ \
  -H "Origin: http://localhost:3000" \
  -H "Access-Control-Request-Method: POST" \
  -v
```

Должны быть заголовки:
```
< Access-Control-Allow-Origin: *
< Access-Control-Allow-Methods: *
< Access-Control-Allow-Headers: *
```

## Если ничего не помогло

1. **Перезапустите бэкенд:**
   ```bash
   cd backend
   # Ctrl+C
   python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
   ```

2. **Перезапустите фронтенд:**
   ```bash
   cd frontend
   # Ctrl+C
   npm run dev
   ```

3. **Очистите кэш браузера:**
   - Ctrl+Shift+Delete
   - Очистите кэш и cookies
   - Перезагрузите страницу

4. **Проверьте файрвол:**
   - Убедитесь, что порт 8000 не заблокирован
   - Попробуйте отключить антивирус временно

## Успешное подключение ✅

Если все работает, вы должны видеть:
- ✅ Бэкенд запущен на http://localhost:8000
- ✅ Фронтенд запущен на http://localhost:5173 (или 3000)
- ✅ Нет CORS ошибок в консоли
- ✅ Запросы к API проходят успешно
- ✅ Маршруты создаются без ошибок

## Дополнительно

После исправления CORS, уведомления о маршрутах будут работать автоматически! 🎉
