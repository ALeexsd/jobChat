# 🐛 Отладка проблемы с логином

## Проблема
Ошибка 422 (Unprocessable Entity) при попытке входа.

## ✅ Что проверено

### 1. Backend работает
Проверено через PowerShell - логин работает:
```powershell
Invoke-WebRequest -Uri "http://localhost:8000/api/auth/login" -Method POST -Headers @{"Content-Type"="application/json"} -Body '{"username":"testuser","password":"test123"}'
# Результат: 200 OK, токены получены
```

### 2. Тестовый пользователь существует
```
Username: testuser
Password: test123
```

## 🔍 Что проверить в браузере

### Откройте консоль (F12) и проверьте:

#### 1. Логи перед отправкой:
```
Attempting login with: {username: "...", password: "..."}
Login credentials: {username: "...", password: "..."}
```

**Проверьте:**
- ✅ username не пустой?
- ✅ password не пустой?
- ✅ Нет лишних пробелов?

#### 2. API Request лог:
```
API Request: {
  url: "/auth/login",
  method: "post",
  data: {username: "...", password: "..."},
  headers: {...}
}
```

**Проверьте:**
- ✅ Content-Type: application/json?
- ✅ data содержит username и password?
- ✅ Значения не undefined?

#### 3. API Error лог:
```
API Error: {
  url: "/auth/login",
  status: 422,
  data: {...},
  message: "..."
}
```

**Проверьте:**
- ❓ Что в data? (детали ошибки от backend)

## 🧪 Тесты

### Тест 1: Прямой fetch
Откройте консоль браузера и выполните:
```javascript
fetch('http://localhost:8000/api/auth/login', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({username: 'testuser', password: 'test123'})
})
.then(r => r.json())
.then(console.log)
.catch(console.error)
```

**Ожидаемый результат:**
```json
{
  "access_token": "...",
  "refresh_token": "...",
  "token_type": "bearer"
}
```

### Тест 2: Через тестовую страницу
1. Откройте `http://localhost:3000/test-login.html`
2. Нажмите "Test Login"
3. Проверьте результат

### Тест 3: Network tab
1. Откройте DevTools → Network
2. Попробуйте войти
3. Найдите запрос к `/api/auth/login`
4. Проверьте:
   - Request Headers
   - Request Payload
   - Response

## 🔧 Возможные причины

### 1. Пустые поля
```javascript
// Проверьте в консоли:
formData.value
// Должно быть: {username: "testuser", password: "test123"}
// НЕ должно быть: {username: "", password: ""}
```

### 2. Неправильная сериализация
```javascript
// Проверьте, что отправляется JSON, а не FormData
// В Network tab → Headers → Request Payload должен быть JSON
```

### 3. CORS проблема
```javascript
// Проверьте в консоли, нет ли ошибок CORS
// Должен быть OPTIONS запрос перед POST
```

### 4. Неправильный URL
```javascript
// Проверьте, что запрос идет на:
// http://localhost:8000/api/auth/login
// А НЕ на:
// http://localhost:3000/api/auth/login
```

## 📝 Что делать

### Шаг 1: Соберите информацию
1. Откройте консоль браузера (F12)
2. Попробуйте войти
3. Скопируйте ВСЕ логи из консоли
4. Скопируйте Request Payload из Network tab

### Шаг 2: Проверьте данные
```javascript
// В консоли выполните:
console.log('Username:', document.getElementById('username').value)
console.log('Password:', document.getElementById('password').value)
```

### Шаг 3: Тест через fetch
Выполните Тест 1 из раздела "Тесты" выше

### Шаг 4: Проверьте backend
```bash
# Проверьте логи backend:
docker-compose logs backend --tail 100
```

## 💡 Подсказки

### Если username или password пустые:
- Проверьте, что поля заполнены
- Проверьте v-model привязку
- Попробуйте ввести данные заново

### Если данные не JSON:
- Проверьте Content-Type header
- Проверьте, что используется JSON.stringify

### Если 422 с деталями:
- Посмотрите error.response.data в консоли
- Там будет точная причина от backend

## 🎯 Быстрый тест

Выполните в консоли браузера:
```javascript
// 1. Проверка прямого запроса
await fetch('http://localhost:8000/api/auth/login', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({username: 'testuser', password: 'test123'})
}).then(r => r.json()).then(console.log)

// 2. Проверка через axios (если есть)
await axios.post('http://localhost:8000/api/auth/login', {
  username: 'testuser',
  password: 'test123'
}).then(r => console.log(r.data))
```

Если оба теста работают - проблема в форме.
Если не работают - проблема в backend или CORS.

## 📞 Следующие шаги

1. Выполните быстрый тест выше
2. Соберите логи из консоли
3. Проверьте Network tab
4. Сообщите результаты

---

**Важно:** Теперь в консоли есть детальное логирование:
- `API Request` - что отправляется
- `API Response` - что приходит
- `API Error` - детали ошибки

Проверьте эти логи!
