# 🚀 Установка на VPS Ubuntu - Полное руководство

Комплексное руководство по развертыванию корпоративного мессенджера на VPS с Ubuntu.

## 📚 Содержание

1. [Быстрый старт](#-быстрый-старт)
2. [Требования](#-требования)
3. [Подготовка](#-подготовка)
4. [Установка](#-установка)
5. [Управление](#-управление)
6. [Мониторинг](#-мониторинг)
7. [Обслуживание](#-обслуживание)
8. [Решение проблем](#-решение-проблем)

## ⚡ Быстрый старт

### За 5 минут до запуска

```bash
# 1. Подключитесь к серверу
ssh root@ваш-сервер-ip

# 2. Скачайте проект
cd /tmp
git clone <repository-url> corporate-messenger
cd corporate-messenger

# 3. Запустите установку
chmod +x deploy-ubuntu.sh
sudo bash deploy-ubuntu.sh
```

Скрипт запросит домен и email, затем автоматически установит всё необходимое.

**Готово!** Откройте https://ваш-домен.com

**Данные для входа:**
- Логин: `admin`
- Пароль: `admin123`

📖 **Подробнее:** [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md)

## 📋 Требования

### Минимальные требования
- Ubuntu 20.04 / 22.04 LTS
- 2 CPU cores
- 4 GB RAM
- 20 GB SSD
- Домен с A-записью

### Рекомендуемые требования
- Ubuntu 22.04 LTS
- 4 CPU cores
- 8 GB RAM
- 50 GB SSD
- Домен с A-записью

📖 **Подробнее:** [VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md)

## 🛠️ Подготовка

### 1. Создание VPS

Рекомендуемые провайдеры:
- **Hetzner** - лучшее соотношение цена/качество (от €5.83/месяц)
- **DigitalOcean** - простота использования (от $12/месяц)
- **Vultr** - много локаций (от $12/месяц)

### 2. Настройка домена

Создайте A-запись в DNS:
```
Тип: A
Имя: chat (или @)
Значение: IP-адрес-вашего-сервера
TTL: 3600
```

Проверка:
```bash
nslookup ваш-домен.com
```

### 3. Подключение к серверу

```bash
ssh root@ваш-сервер-ip
```

Рекомендуется настроить SSH ключи для безопасности.

## 🚀 Установка

### Автоматическая установка (рекомендуется)

```bash
cd /tmp
git clone <repository-url> corporate-messenger
cd corporate-messenger
chmod +x deploy-ubuntu.sh
sudo bash deploy-ubuntu.sh
```

**Что установит скрипт:**
- ✅ Docker и Docker Compose
- ✅ Nginx (reverse proxy)
- ✅ Certbot (SSL сертификаты)
- ✅ Firewall (UFW)
- ✅ PostgreSQL (в контейнере)
- ✅ Backend (FastAPI)
- ✅ Frontend (Vue.js)
- ✅ Автоматические бэкапы
- ✅ Администратор по умолчанию

**Время установки:** 10-15 минут

### Ручная установка

Если нужен больший контроль над процессом:

📖 **Подробная инструкция:** [INSTALL_VPS.md](INSTALL_VPS.md)

## 🎛️ Управление

### Удобные команды

После установки доступны следующие команды:

```bash
# Статус приложения
chat-status

# Просмотр логов (в реальном времени)
chat-logs

# Перезапуск приложения
chat-restart

# Остановка приложения
chat-stop

# Запуск приложения
chat-start

# Создание бэкапа
chat-backup

# Проверка здоровья
chat-health

# Dashboard
chat-dashboard

# Мониторинг
chat-monitor
```

### Ручное управление

```bash
cd /opt/corporate-messenger

# Статус контейнеров
docker-compose -f docker-compose.prod.yml ps

# Логи
docker-compose -f docker-compose.prod.yml logs -f

# Перезапуск
docker-compose -f docker-compose.prod.yml restart

# Остановка
docker-compose -f docker-compose.prod.yml down

# Запуск
docker-compose -f docker-compose.prod.yml up -d
```

## 📊 Мониторинг

### Настройка мониторинга

```bash
sudo bash monitoring-setup.sh ваш-email@example.com
```

**Что настроит:**
- ✅ Автоматические проверки каждые 5 минут
- ✅ Ежедневные отчеты на email (9:00)
- ✅ Алерты при проблемах
- ✅ Мониторинг контейнеров
- ✅ Мониторинг ресурсов
- ✅ Мониторинг доступности
- ✅ Мониторинг логов

### Проверка здоровья

```bash
# Быстрая проверка
chat-health

# С указанием домена
chat-health ваш-домен.com

# Dashboard
chat-dashboard
```

### Просмотр метрик

```bash
# Использование ресурсов
docker stats

# Статус контейнеров
chat-status

# Дисковое пространство
df -h

# Память
free -h
```

## 🔧 Обслуживание

### Обновление приложения

```bash
cd /opt/corporate-messenger
sudo bash update-app.sh
```

Скрипт автоматически:
1. Создаст бэкап
2. Остановит сервисы
3. Обновит код
4. Пересоберет образы
5. Запустит сервисы
6. Применит миграции

### Бэкапы

#### Автоматические бэкапы
Настраиваются автоматически при установке:
- Создаются каждый день в 2:00
- Хранятся 30 дней
- Сжимаются (gzip)
- Хранятся в `/opt/corporate-messenger/backups/`

#### Ручное создание бэкапа
```bash
chat-backup
# или
/opt/corporate-messenger/backup.sh
```

#### Восстановление из бэкапа
```bash
cd /opt/corporate-messenger
sudo bash restore-backup.sh backups/backup_20240101_120000.sql.gz
```

### Обновление SSL сертификата

Автоматически обновляется каждое воскресенье.

Ручное обновление:
```bash
sudo certbot renew
sudo systemctl reload nginx
```

### Очистка диска

```bash
# Очистка Docker
docker system prune -a --volumes

# Удаление старых бэкапов (>30 дней)
find /opt/corporate-messenger/backups -name "*.sql.gz" -mtime +30 -delete

# Очистка логов
docker-compose -f /opt/corporate-messenger/docker-compose.prod.yml logs --tail=0
```

## 🆘 Решение проблем

### Контейнеры не запускаются

```bash
# Проверка логов
chat-logs

# Проверка статуса
chat-status

# Пересоздание контейнеров
cd /opt/corporate-messenger
docker-compose -f docker-compose.prod.yml up -d --force-recreate
```

### Приложение недоступно

```bash
# Проверка портов
sudo netstat -tlnp | grep -E "80|443"

# Проверка Nginx
sudo nginx -t
sudo systemctl status nginx
sudo systemctl restart nginx

# Проверка контейнеров
chat-status

# Полная перезагрузка
chat-restart
```

### SSL не работает

```bash
# Проверка сертификата
sudo certbot certificates

# Обновление сертификата
sudo certbot renew --force-renewal

# Перезапуск Nginx
sudo systemctl restart nginx
```

### База данных недоступна

```bash
# Проверка контейнера PostgreSQL
docker ps | grep postgres

# Подключение к БД
docker-compose -f /opt/corporate-messenger/docker-compose.prod.yml exec postgres psql -U chatuser -d chatdb

# Перезапуск БД
docker-compose -f /opt/corporate-messenger/docker-compose.prod.yml restart postgres
```

### Нет места на диске

```bash
# Проверка использования
df -h

# Очистка Docker
docker system prune -a --volumes

# Удаление старых бэкапов
find /opt/corporate-messenger/backups -name "*.sql.gz" -mtime +7 -delete

# Очистка логов
truncate -s 0 /var/log/syslog
```

### Высокая нагрузка

```bash
# Проверка ресурсов
docker stats

# Проверка процессов
htop

# Увеличение ресурсов контейнера
# Отредактируйте docker-compose.prod.yml:
resources:
  limits:
    cpus: '4'
    memory: 4G
```

## 🔒 Безопасность

### После установки обязательно:

1. **Смените пароль администратора**
   - Войдите в приложение
   - Профиль → Настройки → Сменить пароль

2. **Измените SECRET_KEY**
   ```bash
   # Генерация нового ключа
   openssl rand -hex 32
   
   # Редактирование .env
   sudo nano /opt/corporate-messenger/backend/.env
   
   # Перезапуск
   chat-restart
   ```

3. **Измените пароль PostgreSQL**
   ```bash
   sudo nano /opt/corporate-messenger/backend/.env
   sudo nano /opt/corporate-messenger/.env.prod
   chat-restart
   ```

4. **Настройте Fail2Ban** (опционально)
   ```bash
   sudo apt install fail2ban -y
   sudo systemctl enable fail2ban
   ```

5. **Отключите root login по паролю**
   ```bash
   sudo nano /etc/ssh/sshd_config
   # Установите: PermitRootLogin prohibit-password
   sudo systemctl restart sshd
   ```

## 📁 Структура файлов

```
/opt/corporate-messenger/
├── backend/
│   ├── app/              # Код приложения
│   ├── .env              # Конфигурация backend
│   └── Dockerfile
├── frontend/
│   ├── src/              # Код приложения
│   ├── .env              # Конфигурация frontend
│   └── Dockerfile
├── backups/              # Бэкапы БД
├── docker-compose.prod.yml
├── .env.prod             # Пароль PostgreSQL
└── backup.sh             # Скрипт бэкапа

/etc/nginx/
└── sites-available/
    └── chat              # Конфигурация Nginx

/opt/
├── monitor-chat.sh       # Скрипт мониторинга
├── daily-report.sh       # Ежедневный отчет
├── dashboard.sh          # Dashboard
└── check-health.sh       # Проверка здоровья
```

## 📖 Дополнительная документация

- [QUICK_INSTALL_VPS.md](QUICK_INSTALL_VPS.md) - Быстрая установка за 5 минут
- [INSTALL_VPS.md](INSTALL_VPS.md) - Подробная инструкция по установке
- [VPS_REQUIREMENTS.md](VPS_REQUIREMENTS.md) - Требования и выбор провайдера
- [DEPLOYMENT.md](DEPLOYMENT.md) - Production развертывание
- [README.md](README.md) - Общая информация о проекте

## 🔧 Скрипты

В проекте доступны следующие скрипты:

| Скрипт | Описание |
|--------|----------|
| `deploy-ubuntu.sh` | Автоматическая установка на Ubuntu |
| `update-app.sh` | Обновление приложения |
| `restore-backup.sh` | Восстановление из бэкапа |
| `check-health.sh` | Проверка здоровья системы |
| `monitoring-setup.sh` | Настройка мониторинга |
| `backup.sh` | Создание бэкапа БД |

## ✅ Чеклист после установки

- [ ] Приложение доступно по HTTPS
- [ ] SSL сертификат работает корректно
- [ ] Вход под admin работает
- [ ] Пароль администратора изменен
- [ ] SECRET_KEY изменен
- [ ] Пароль PostgreSQL изменен
- [ ] Бэкапы настроены и работают
- [ ] Firewall настроен
- [ ] Мониторинг настроен (опционально)
- [ ] Fail2Ban установлен (опционально)
- [ ] Автообновление SSL настроено
- [ ] Документация изучена

## 💡 Советы

### Производительность
- Используйте SSD диски
- Включите HTTP/2 (включено по умолчанию)
- Настройте CDN для статики (опционально)
- Используйте Redis для кэширования (опционально)

### Надежность
- Регулярно проверяйте бэкапы
- Мониторьте использование ресурсов
- Настройте алерты
- Храните бэкапы в нескольких местах

### Безопасность
- Регулярно обновляйте систему
- Используйте сильные пароли
- Настройте Fail2Ban
- Мониторьте логи на подозрительную активность

## 📞 Поддержка

### Если возникли проблемы:

1. **Проверьте логи**
   ```bash
   chat-logs
   ```

2. **Проверьте статус**
   ```bash
   chat-status
   chat-health
   ```

3. **Посмотрите документацию**
   - [INSTALL_VPS.md](INSTALL_VPS.md)
   - [DEPLOYMENT.md](DEPLOYMENT.md)

4. **Создайте issue в GitHub**
   - Опишите проблему
   - Приложите логи
   - Укажите конфигурацию сервера

## 🎉 Готово!

Ваш корпоративный мессенджер установлен и готов к работе!

**Следующие шаги:**
1. Войдите в приложение
2. Смените пароль администратора
3. Создайте пользователей
4. Настройте мониторинг
5. Наслаждайтесь использованием!

---

**Сделано с ❤️ для корпоративной коммуникации**
