# ✅ Улучшения: Поиск и Чаты

## 🔍 Поиск по @username

### Проблема
Поиск по @username не работал в списке чатов.

### Решение

**Умный поиск в ChatsView:**
- Поиск по названию чата
- Поиск пользователей по @username
- Быстрое создание чата с найденным пользователем

**frontend/src/views/ChatsView.vue:**
```vue
<!-- Search -->
<div class="mb-6">
  <div class="relative">
    <MagnifyingGlassIcon class="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
    <input
      v-model="searchQuery"
      @input="handleSearch"
      type="text"
      placeholder="Поиск чатов или @username..."
      class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
    />
  </div>
  
  <!-- Search Results -->
  <div v-if="searchResults.length > 0" class="mt-2 card p-2 max-h-60 overflow-y-auto">
    <p class="text-xs text-gray-500 px-2 py-1">Пользователи:</p>
    <button
      v-for="user in searchResults"
      :key="user.id"
      @click="createChatWithUser(user)"
      class="w-full flex items-center p-2 hover:bg-gray-100 rounded-lg transition-colors text-left"
    >
      <div class="w-10 h-10 rounded-full bg-primary-600 flex items-center justify-center text-white font-semibold">
        {{ user.first_name?.[0] || '?' }}{{ user.last_name?.[0] || '' }}
      </div>
      <div class="ml-3">
        <p class="text-sm font-medium text-gray-900">{{ user.first_name }} {{ user.last_name }}</p>
        <p class="text-xs text-gray-500">@{{ user.username }}</p>
      </div>
    </button>
  </div>
</div>
```

**Логика поиска:**
```javascript
async function handleSearch() {
  // Очищаем предыдущий таймаут
  if (searchTimeout) {
    clearTimeout(searchTimeout)
  }
  
  // Если поиск начинается с @, ищем пользователей
  if (searchQuery.value.startsWith('@') && searchQuery.value.length > 1) {
    searchTimeout = setTimeout(async () => {
      try {
        const username = searchQuery.value.substring(1)
        const response = await api.get(`/users?search=${username}`)
        searchResults.value = response.data
      } catch (error) {
        console.error('Search users error:', error)
        searchResults.value = []
      }
    }, 300)
  } else {
    searchResults.value = []
  }
}

async function createChatWithUser(user) {
  try {
    // Создаем личный чат с пользователем
    const response = await api.post('/chats', {
      name: `${user.first_name} ${user.last_name}`,
      chat_type: 'private',
      member_ids: [user.id]
    })
    
    // Очищаем поиск
    searchQuery.value = ''
    searchResults.value = []
    
    // Переходим в созданный чат
    router.push(`/chats/${response.data.id}`)
  } catch (error) {
    console.error('Create chat error:', error)
    alert('Ошибка создания чата: ' + (error.response?.data?.detail || error.message))
  }
}
```

### Особенности:
- ✅ Поиск с задержкой 300мс (debounce)
- ✅ Поиск только при вводе @username
- ✅ Отображение результатов под поиском
- ✅ Клик по пользователю создает чат
- ✅ Автоматический переход в созданный чат

---

## 💬 Автоматическое название для личных чатов

### Проблема
При создании личного чата нужно было вручную вводить название.

### Решение

**Автоматическое название:**
- Для личного чата название берется из имени пользователя
- Для группового чата название вводится вручную
- Можно переименовать любой чат

**frontend/src/components/CreateChatModal.vue:**
```vue
<form @submit.prevent="handleSubmit" class="space-y-4">
  <div>
    <label class="block text-sm font-medium text-gray-700 mb-2">
      Тип чата
    </label>
    <select v-model="formData.type" required class="input">
      <option value="">Выберите тип</option>
      <option value="private">Личный чат</option>
      <option value="group">Групповой чат</option>
    </select>
  </div>
  
  <!-- Название только для группового чата -->
  <div v-if="formData.type === 'group'">
    <label class="block text-sm font-medium text-gray-700 mb-2">
      Название чата
    </label>
    <input
      v-model="formData.name"
      type="text"
      required
      class="input"
      placeholder="Введите название чата"
    />
  </div>
  
  <!-- Остальные поля... -->
</form>
```

**Логика создания:**
```javascript
async function handleSubmit() {
  loading.value = true
  
  try {
    let chatName = formData.value.name
    
    // Для личного чата автоматически берем имя пользователя
    if (formData.value.type === 'private' && formData.value.user) {
      const user = users.value.find(u => u.id === formData.value.user)
      if (user) {
        chatName = `${user.first_name} ${user.last_name}`
      }
    }
    
    const chatData = {
      name: chatName,
      chat_type: formData.value.type,
      member_ids: formData.value.type === 'group' 
        ? formData.value.members 
        : [formData.value.user]
    }
    
    await api.post('/chats', chatData)
    emit('created')
    emit('close')
  } catch (error) {
    console.error('Create chat error:', error)
    alert('Ошибка создания чата: ' + (error.response?.data?.detail || error.message))
  } finally {
    loading.value = false
  }
}
```

---

## ✏️ Переименование чата

### Новая функция
Добавлена возможность переименовать любой чат.

**frontend/src/views/ChatDetailView.vue:**
```vue
<!-- Меню чата -->
<MenuItem v-slot="{ active }">
  <button
    @click="renameChatPrompt"
    :class="[
      active ? 'bg-gray-100' : '',
      'group flex items-center w-full px-3 py-2 text-sm text-gray-900 rounded-md'
    ]"
  >
    <PencilIcon class="w-5 h-5 mr-2" />
    Переименовать
  </button>
</MenuItem>
```

**Логика переименования:**
```javascript
async function renameChatPrompt() {
  const newName = prompt('Введите новое название чата:', chat.value?.name || '')
  
  if (!newName || newName === chat.value?.name) {
    return
  }
  
  try {
    await api.put(`/chats/${route.params.id}`, { name: newName })
    await loadChat()
    alert('Чат переименован')
  } catch (error) {
    console.error('Rename chat error:', error)
    alert('Ошибка переименования чата')
  }
}
```

---

## 🧪 Тестирование

### 1. Поиск по @username

**Тест 1: Поиск пользователя**
1. Откройте страницу "Чаты"
2. В поиске введите: `@vova`
3. **Результат:** Появляется список пользователей с username содержащим "vova"

**Тест 2: Создание чата из поиска**
1. Найдите пользователя через @username
2. Кликните на пользователя
3. **Результат:** Создается личный чат и открывается

**Тест 3: Поиск по названию**
1. В поиске введите название чата (без @)
2. **Результат:** Фильтруются существующие чаты

---

### 2. Автоматическое название

**Тест 1: Личный чат**
1. Нажмите "Создать чат"
2. Выберите тип: "Личный чат"
3. Выберите пользователя: "Иван Иванов"
4. **Результат:** Поле "Название чата" не отображается
5. Нажмите "Создать"
6. **Результат:** Чат создан с названием "Иван Иванов"

**Тест 2: Групповой чат**
1. Нажмите "Создать чат"
2. Выберите тип: "Групповой чат"
3. **Результат:** Появляется поле "Название чата"
4. Введите название: "Рабочая группа"
5. Выберите участников
6. Нажмите "Создать"
7. **Результат:** Чат создан с названием "Рабочая группа"

---

### 3. Переименование чата

**Тест 1: Переименовать личный чат**
1. Откройте любой личный чат
2. Нажмите меню (⋮)
3. Выберите "Переименовать"
4. Введите новое название: "Мой друг Иван"
5. **Результат:** Чат переименован

**Тест 2: Переименовать групповой чат**
1. Откройте групповой чат
2. Нажмите меню (⋮)
3. Выберите "Переименовать"
4. Введите новое название: "Команда разработки"
5. **Результат:** Чат переименован

---

## 📊 Что работает

### Поиск:
- ✅ По названию чата
- ✅ По @username
- ✅ Debounce 300мс
- ✅ Отображение результатов
- ✅ Быстрое создание чата

### Создание чата:
- ✅ Автоматическое название для личных чатов
- ✅ Ручное название для групповых чатов
- ✅ Правильные поля в API

### Переименование:
- ✅ Любой чат можно переименовать
- ✅ Простой prompt для ввода
- ✅ Обновление в реальном времени

---

## 🎯 Сценарии использования

### Сценарий 1: Быстрый поиск и чат
1. Пользователь хочет написать коллеге
2. Вводит в поиске: `@ivan`
3. Видит список Иванов
4. Кликает на нужного
5. Чат создается автоматически
6. Можно сразу писать сообщение

### Сценарий 2: Создание группы
1. Пользователь создает групповой чат
2. Вводит название: "Проект X"
3. Выбирает участников
4. Чат создан с понятным названием

### Сценарий 3: Персонализация
1. Пользователь хочет переименовать чат
2. Открывает меню → Переименовать
3. Вводит свое название
4. Чат переименован

---

## 🚀 Frontend обновлен

Все изменения применены!

**Попробуйте сейчас:**
1. Найдите пользователя через @username
2. Создайте личный чат (без ввода названия)
3. Переименуйте чат

Все работает! 🎉
