# ⚡ Быстрая отладка логина

## 🎯 Что делать СЕЙЧАС

### 1. Откройте консоль браузера (F12)

### 2. Выполните этот код:
```javascript
fetch('http://localhost:8000/api/auth/login', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({username: 'testuser', password: 'test123'})
})
.then(r => r.json())
.then(data => {
  console.log('✅ SUCCESS:', data)
  alert('Логин работает! Токен получен.')
})
.catch(err => {
  console.error('❌ ERROR:', err)
  alert('Ошибка: ' + err.message)
})
```

### 3. Результаты:

#### Если ✅ SUCCESS:
- Backend работает
- Проблема в форме Vue
- Проверьте логи в консоли при входе через форму

#### Если ❌ ERROR:
- Проблема в backend или CORS
- Проверьте, что backend запущен: `docker-compose ps`
- Проверьте логи: `docker-compose logs backend --tail 50`

---

## 🔍 Проверка формы

### В консоли при входе должны быть логи:

```
1. Attempting login with: {username: "...", password: "..."}
2. Login credentials: {username: "...", password: "..."}
3. API Request: {url: "/auth/login", method: "post", data: {...}}
4. API Response: {url: "/auth/login", status: 200, data: {...}}
   ИЛИ
   API Error: {url: "/auth/login", status: 422, data: {...}}
```

### Что проверить:
- ✅ username и password НЕ пустые?
- ✅ Нет undefined?
- ✅ Content-Type: application/json?

---

## 🚀 Быстрое решение

### Если форма не работает:

1. **Очистите кэш браузера** (Ctrl+Shift+Delete)
2. **Перезагрузите страницу** (Ctrl+F5)
3. **Попробуйте другой браузер**
4. **Проверьте, что поля заполнены**

### Если backend не работает:

```bash
# Перезапустите backend
docker-compose restart backend

# Проверьте логи
docker-compose logs backend --tail 50

# Проверьте статус
docker-compose ps
```

---

## 📋 Чеклист

- [ ] Backend запущен (`docker-compose ps`)
- [ ] Тестовый пользователь создан (testuser/test123)
- [ ] Прямой fetch работает (тест выше)
- [ ] Консоль открыта (F12)
- [ ] Логи видны при входе
- [ ] Поля формы заполнены
- [ ] Нет ошибок в консоли до входа

---

## 💡 Подсказка

**Самая частая причина 422:**
- Пустые поля (username или password = "")
- Проверьте в консоли: `Attempting login with: {...}`
- Если там пустые значения - проблема в форме

**Проверка:**
```javascript
// В консоли браузера:
document.getElementById('username').value
document.getElementById('password').value
// Должны быть НЕ пустыми
```

---

## ✅ Если все работает

После успешного входа:
1. Должны увидеть главную страницу
2. Sidebar слева
3. Профиль внизу
4. Можно создавать чаты, задачи, заметки

---

## 🆘 Если ничего не помогло

Выполните и пришлите результаты:

```javascript
// 1. Тест backend
fetch('http://localhost:8000/api/auth/login', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({username: 'testuser', password: 'test123'})
}).then(r => r.json()).then(console.log).catch(console.error)

// 2. Проверка полей
console.log({
  username: document.getElementById('username')?.value,
  password: document.getElementById('password')?.value
})

// 3. Проверка formData
// (после попытки входа в консоли должен быть лог)
```

Скопируйте ВСЕ логи из консоли!
